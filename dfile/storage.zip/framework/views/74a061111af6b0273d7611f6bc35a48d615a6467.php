<?php $__env->startSection('title', __('All Events')); ?>
<?php $__env->startSection('content'); ?>

    <div class="pb-20 bg-scroll min-h-screen" style="background-image: url('images/events.png')">

        

        <div
            class="mt-5 3xl:mx-52 2xl:mx-28 1xl:mx-28 xl:mx-36 xlg:mx-32 lg:mx-36 xxmd:mx-24 xmd:mx-32 md:mx-28 sm:mx-20 msm:mx-16 xsm:mx-10 xxsm:mx-5 z-10 relative">
            <div
                class="absolute bg-blue blur-3xl opacity-10 s:bg-opacity-10 3xl:w-[370px] 3xl:h-[370px] 2xl:w-[300px] 2xl:h-[300px] 1xl:w-[300px] xmd:w-[300px] xmd:h-[300px] sm:w-[200px] sm:h-[300px] xxsm:w-[300px] xxsm:h-[300px] rounded-full -mt-5 2xl:-ml-20 1xl:-ml-20 sm:ml-2 xxsm:-ml-7">
            </div>
            <div class="flex justify-start pt-5 z-10">
                <p
                    class="font-poppins font-semibold md:text-5xl xxsm:text-2xl xsm:text-2xl sm:text-2xl text-blue leading-10 ">
                    <?php echo e(__('Events')); ?></p>&nbsp;&nbsp;
                <p
                    class="font-poppins font-medium md:text-2xl xxsm:text-xl xsm:text-xl sm:text-xl text-blue leading-10 pt-3">
                    ( <?php echo e($events->count()); ?> )</p>
            </div>
            <div class="mb-4 pt-4">
                <ul class="flex flex-wrap -mb-px text-lg font-medium text-center events xmd:space-y-0 md:space-y-2 sm:space-y-2 xxsm:space-y-2"
                    id="myTab" data-tabs-toggle="#myTabContent" role="tablist">
                    <li class="mr-2 ">
                        <button
                            class="inline-block p-4 px-6 py-3 rounded-md z-20 font-poppins shadow-md focus:outline-none relative"
                            id="all_events" data-tabs-target="#events" type="button" role="tab" aria-controls="events"
                            aria-selected="false"><?php echo e(__('All Events')); ?></button>
                    </li>
                    <li class="mr-2">
                        <button
                            class="inline-block z-20 px-5 py-3 rounded-md font-poppins shadow-md focus:outline-none relative"
                            id="online_events" data-tabs-target="#online" type="button" role="tab"
                            aria-controls="online"
                            aria-selected="false"><?php echo e(__('Online Events')); ?>(<?php echo e($onlinecount); ?>)</button>
                    </li>
                    <li class="mr-2">
                        <button
                            class="inline-block z-20 px-5 py-3 rounded-md font-poppins shadow-md focus:outline-none relative"
                            id="venue_events" data-tabs-target="#venue" type="button" role="tab" aria-controls="venue"
                            aria-selected="false"><?php echo e(__('Venue Events')); ?>(<?php echo e($offlinecount); ?>)</button>
                    </li>
                </ul>
            </div>
            <?php if(count($events) == 0): ?>
                <div class="font-poppins font-medium text-lg leading-4 text-black mt-10  capitalize">
                    <?php echo e(__('There are no events added yet')); ?>

                </div>
            <?php endif; ?>
            <div id="myTabContent">
                <div class="hidden" id="events" role="tabpanel" aria-labelledby="all_events">
                    <div
                        class="grid gap-x-7 1xl:grid-cols-4 xl:grid-cols-4 xlg:grid-cols-4 xmd:grid-cols-2 xxmd:gap-y-7 xmd:gap-y-7 xxsm:gap-y-7 sm:grid-cols-1 sm:gap-y-7 msm:grid-cols-1 xxsm:grid-cols-1 justify-between pt-10 z-30 relative">
                        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div
                                class="shadow-2xl p-5 rounded-lg bg-white hover:scale-110 transition-all duration-500 cursor-pointer">
                                <a href="<?php echo e(url('/event/' . $item->id . '/' . Str::slug($item->name))); ?>">
                                    <img src="<?php echo e(url('images/upload/' . $item->image)); ?>" alt=""
                                        class="h-40 rounded-lg w-full object-cover bg-cover ">
                                    <p class="font-popping font-semibold text-xl leading-8 pt-2"><?php echo e($item->name); ?></p>
                                    <p class="font-poppins font-normal text-base leading-6 text-gray pt-1">
                                        <?php echo e(Carbon\Carbon::parse($item->start_time)->format('d M Y')); ?> -
                                        <?php echo e(Carbon\Carbon::parse($item->end_time)->format('d M Y')); ?>

                                    </p>
                                </a>
                                <div class="flex justify-between mt-7">
                                    <?php if(Auth::guard('appuser')->user()): ?>
                                        <?php if(Str::contains($user->favorite, $item->id)): ?>
                                            <a href="javascript:void(0);" class="like"
                                                onclick="addFavorite('<?php echo e($item->id); ?>','<?php echo e('event'); ?>')"><img
                                                    src="<?php echo e(url('images/heart-fill.svg')); ?>" alt=""
                                                    class="object-cover bg-cover fillLike bg-white-light p-2 rounded-lg"></a>
                                        <?php else: ?>
                                            <a href="javascript:void(0);" class="like"
                                                onclick="addFavorite('<?php echo e($item->id); ?>','<?php echo e('event'); ?>')"><img
                                                    src="<?php echo e(url('images/heart.svg')); ?>" alt=""
                                                    class="object-cover bg-cover fillLike bg-white-light p-2 rounded-lg"></a>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    <a type="button" id="EventDetails<?php echo e($item->id); ?>"
                                        href="<?php echo e(url('/event/' . $item->id . '/' . Str::slug($item->name))); ?>"
                                        class="text-primary text-center font-poppins font-medium text-base leading-7 flex"><?php echo e(__('View Details')); ?>

                                        <i class="fa-solid fa-arrow-right w-3 h-3 mt-1.5 ml-2"></i>
                                    </a>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="hidden" id="online" role="tabpanel" aria-labelledby="online_events">
                    <div
                        class="grid gap-x-7 1xl:grid-cols-4 xl:grid-cols-4 xlg:grid-cols-4 xmd:grid-cols-2 xxmd:gap-y-7 xmd:gap-y-7 xxsm:gap-y-7 sm:grid-cols-1 sm:gap-y-7 msm:grid-cols-1 xxsm:grid-cols-1 justify-between pt-10 z-30 relative">
                        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($item->type == 'online'): ?>
                                <div class="shadow-2xl p-5 rounded-lg bg-white hover:scale-110 transition-all duration-500">
                                    <a href="<?php echo e(url('/event/' . $item->id . '/' . Str::slug($item->name))); ?>">

                                        <img src="<?php echo e(url('images/upload/' . $item->image)); ?>" alt=""
                                            class="h-40 rounded-lg w-full object-cover bg-cover ">
                                        <p class="font-popping font-semibold text-xl leading-8 pt-2">
                                            <?php echo e($item->name); ?></p>
                                        <p class="font-poppins font-normal text-base leading-6 text-gray pt-1">
                                            <?php echo e(Carbon\Carbon::parse($item->start_time)->format('d M Y')); ?> -
                                            <?php echo e(Carbon\Carbon::parse($item->end_time)->format('d M Y')); ?></p>
                                    </a>
                                    <div class="flex justify-between mt-7">
                                        <?php if(Auth::guard('appuser')->user()): ?>
                                            <?php if(Str::contains($user->favorite, $item->id)): ?>
                                                <a href="javascript:void(0);" class="like"
                                                    onclick="addFavorite('<?php echo e($item->id); ?>','<?php echo e('event'); ?>')"><img
                                                        src="<?php echo e(url('images/heart-fill.svg')); ?>" alt=""
                                                        class="object-cover bg-cover fillLike bg-white-light p-2 rounded-lg"></a>
                                            <?php else: ?>
                                                <a href="javascript:void(0);" class="like"
                                                    onclick="addFavorite('<?php echo e($item->id); ?>','<?php echo e('event'); ?>')"><img
                                                        src="<?php echo e(url('images/heart.svg')); ?>" alt=""
                                                        class="object-cover bg-cover fillLike bg-white-light p-2 rounded-lg"></a>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                        <a type="button"
                                            href="<?php echo e(url('/event/' . $item->id . '/' . Str::slug($item->name))); ?>"
                                            class=" text-primary text-center font-poppins font-medium text-base leading-7 flex"><?php echo e(__('View Details')); ?>

                                            <i class="fa-solid fa-arrow-right w-3 h-3 mt-1.5 ml-2"></i>
                                        </a>
                                    </div>
                                </div>
                            <?php endif; ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="hidden" id="venue" role="tabpanel" aria-labelledby="venue_events">
                    <div
                        class="grid gap-x-7 1xl:grid-cols-4 xl:grid-cols-4 xlg:grid-cols-4 xmd:grid-cols-2 xxmd:gap-y-7 xmd:gap-y-7 xxsm:gap-y-7 sm:grid-cols-1 sm:gap-y-7 msm:grid-cols-1 xxsm:grid-cols-1 justify-between pt-10 z-30 relative">
                        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($item->type == 'offline'): ?>
                                <div
                                    class="shadow-2xl p-5 rounded-lg bg-white hover:scale-110 transition-all duration-500">
                                    <a href="<?php echo e(url('/event/' . $item->id . '/' . Str::slug($item->name))); ?>">
                                        <img src="<?php echo e(url('images/upload/' . $item->image)); ?>" alt=""
                                            class="h-40 rounded-lg w-full object-cover bg-cover">
                                        <p class="font-popping font-semibold text-xl leading-8 pt-2">
                                            <?php echo e($item->name); ?></p>
                                        <p class="font-poppins font-normal text-base leading-6 text-gray pt-1">
                                            <?php echo e(Carbon\Carbon::parse($item->start_time)->format('d M Y')); ?> -
                                            <?php echo e(Carbon\Carbon::parse($item->end_time)->format('d M Y')); ?></p>
                                        <div class="flex justify-between mt-7">
                                            <?php if(Auth::guard('appuser')->user()): ?>
                                                <?php if(Str::contains($user->favorite, $item->id)): ?>
                                                    <a href="javascript:void(0);" class="like"
                                                        onclick="addFavorite('<?php echo e($item->id); ?>','<?php echo e('event'); ?>')"><img
                                                            src="<?php echo e(url('images/heart-fill.svg')); ?>" alt=""
                                                            class="object-cover bg-cover fillLike bg-white-light p-2 rounded-lg"></a>
                                                <?php else: ?>
                                                    <a href="javascript:void(0);" class="like"
                                                        onclick="addFavorite('<?php echo e($item->id); ?>','<?php echo e('event'); ?>')"><img
                                                            src="<?php echo e(url('images/heart.svg')); ?>" alt=""
                                                            class="object-cover bg-cover fillLike bg-white-light p-2 rounded-lg"></a>
                                                <?php endif; ?>
                                            <?php endif; ?>

                                            <a type="button"
                                                href="<?php echo e(url('/event/' . $item->id . '/' . Str::slug($item->name))); ?>"
                                                class=" text-primary text-center font-poppins font-medium text-base leading-7 flex"><?php echo e(__('View Details')); ?>

                                                <i class="fa-solid fa-arrow-right w-3 h-3 mt-1.5 ml-2"></i>
                                            </a>
                                        </div>
                                    </a>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', ['activePage' => 'event'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u726836945/domains/starrtix.com/public_html/app/resources/views/frontend/events.blade.php ENDPATH**/ ?>