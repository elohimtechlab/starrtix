<!-- Step 3: When (Date and Time) -->
<div class="step-content" id="step-3">
    <div class="text-center mb-4">
        <h3 class="step-title">Date and Time</h3>
        <p class="step-subtitle text-muted">Let's get your <span class="text-warning">dates</span> and <span class="text-warning">times</span> down on paper.</p>
    </div>

    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="form-group">
                <label class="form-label"><?php echo e(__('Time-zone')); ?> <span class="text-danger">*</span></label>
                <select name="timezone" class="form-control form-control-lg select2">
                    <option value="UTC+00(Africa/Freetown)">UTC+00(Africa/Freetown)</option>
                    <option value="UTC+01(Europe/London)">UTC+01(Europe/London)</option>
                    <option value="UTC-05(America/New_York)">UTC-05(America/New_York)</option>
                </select>
            </div>

            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label class="form-label"><?php echo e(__('Start Date & Time')); ?> <span class="text-danger">*</span></label>
                        <input type="datetime-local" name="start_time" id="start_time" value="<?php echo e(old('start_time')); ?>"
                            class="form-control form-control-lg <?php $__errorArgs = ['start_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <?php $__errorArgs = ['start_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <small class="form-text text-muted">Select when your event starts</small>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label class="form-label"><?php echo e(__('End Date & Time')); ?> <span class="text-danger">*</span></label>
                        <input type="datetime-local" name="end_time" id="end_time" value="<?php echo e(old('end_time')); ?>"
                            class="form-control form-control-lg <?php $__errorArgs = ['end_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <?php $__errorArgs = ['end_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <small class="form-text text-muted">Select when your event ends</small>
                    </div>
                </div>
            </div>

            <div class="form-navigation text-center mt-4">
                <button type="button" class="btn btn-outline-secondary btn-lg prev-step mr-3">
                    <i class="fas fa-arrow-left mr-2"></i> <?php echo e(__('Previous')); ?>

                </button>
                <button type="button" class="btn btn-primary btn-lg next-step">
                    <?php echo e(__('Next')); ?> <i class="fas fa-arrow-right ml-2"></i>
                </button>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/u726836945/domains/starrtix.com/public_html/app/resources/views/admin/event/wizard-steps/step-3.blade.php ENDPATH**/ ?>