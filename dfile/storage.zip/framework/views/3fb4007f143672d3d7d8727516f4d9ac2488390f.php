<div class="section-header">
    <h1><?php echo e($title); ?></h1>
    <div class="section-header-breadcrumb">
      <div class="breadcrumb-item active"><a href="<?php echo e(url('/admin/home')); ?>"><?php echo e(__('Dashboard')); ?></a></div>
      <?php if(isset($headerData) && $headerData): ?>
        <div class="breadcrumb-item"><a href="<?php echo e(url($url)); ?>"><?php echo e($headerData); ?></a></div>
      <?php endif; ?>
      <div class="breadcrumb-item"><?php echo e($title); ?></a></div>
    </div>
  </div>
<?php /**PATH /home/u726836945/domains/starrtix.com/public_html/app/resources/views/admin/layout/breadcrumbs.blade.php ENDPATH**/ ?>