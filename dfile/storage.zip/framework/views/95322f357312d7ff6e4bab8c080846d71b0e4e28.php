<?php
    $logo = \App\Models\Setting::find(1)->logo;
    $favicon = \App\Models\Setting::find(1)->favicon;
    $modules = \App\Models\Module::all();
?>
<div class="main-sidebar">
    <aside id="sidebar-wrapper">
        <div class="sidebar-brand">
            <a href="#">
                <img src="<?php echo e($logo ? asset('/images/upload/' . $logo) : asset('/images/logo.png')); ?>"
                    class="header-logo w-full  ">
            </a>
        </div>
        <div class="sidebar-brand sidebar-brand-sm">
            <a href="#">
                <img src="<?php echo e($favicon ? asset('/images/upload/' . $favicon) : asset('/images/logo.png')); ?>"
                    class="header-sm-logo h-15 w-15">
            </a>
        </div>
        <ul class="sidebar-menu">
            <li class="menu-header"><?php echo e(__('Menu')); ?></li>
            <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin_dashboard')): ?>
                    <li class="<?php echo e(request()->is('admin/home') ? 'active' : ''); ?>">
                        <a class="nav-link" href="<?php echo e(url('admin/home')); ?>">
                            <i class="fas fa-chart-pie"></i> <span><?php echo e(__('Dashboard')); ?></span>
                        </a>
                    </li>
                <?php endif; ?>
            <?php endif; ?>

            <?php if(auth()->check() && auth()->user()->hasRole('Organizer')): ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('organization_dashboard')): ?>
                    <li class="<?php echo e(request()->is('organization/home') ? 'active' : ''); ?>">
                        <a class="nav-link" href="<?php echo e(url('organization/home')); ?>">
                            <i class="fas fa-chart-pie"></i> <span><?php echo e(__('Dashboard')); ?></span>
                        </a>
                    </li>
                <?php endif; ?>
            <?php endif; ?>
            <?php if(auth()->check() && auth()->user()->hasRole('Organizer')): ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Book_tickets')): ?>
                    <li class="<?php echo e(request()->is('book-ticket') ? 'active' : ''); ?>">
                        <a class="nav-link" href="<?php echo e(url('book-ticket')); ?>">
                            <i class="fas fa-ticket-alt"></i> <span><?php echo e(__('Book Ticket')); ?></span>
                        </a>
                    </li>
                <?php endif; ?>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role_access')): ?>
                <li class="<?php echo e(request()->is('roles*') ? 'active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(url('roles')); ?>">
                        <i class="fas fa-user-secret"></i> <span><?php echo e(__('Role')); ?></span>
                    </a>
                </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_access')): ?>
                <li class="<?php echo e(request()->is('users*') ? 'active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(url('users')); ?>">
                        <i class="fas fa-user-friends"></i> <span><?php echo e(__('Users')); ?></span>
                    </a>
                </li>
            <?php endif; ?>
            <li class="<?php echo e(request()->is('orders/*') ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(url('orders')); ?>">
                    <i class="fas fa-columns"></i><span><?php echo e(__('Orders')); ?></span>
                </a>
            </li>
            <li class="<?php echo e(request()->is('orders-create-for-user') ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(url('orders-create-for-user')); ?>">
                    <i class="fas fa-ticket-simple"></i><span><?php echo e(__('Orders Create')); ?></span>
                </a>
            </li>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('category_access')): ?>
                <li class="<?php echo e(request()->is('category*') ? 'active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(url('category')); ?>">
                        <i class="fas fa-glass-cheers"></i> <span><?php echo e(__('Category')); ?></span>
                    </a>
                </li>
            <?php endif; ?>

            <li class="<?php echo e(request()->is('get-notification*') ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(url('get-notification')); ?>">
                    <i class="fas fa-bell"></i> <span><?php echo e(__('Send Notification')); ?></span>
                </a>
            </li>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('event_access')): ?>
                <li class="<?php echo e(request()->is('events*') ? 'active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(url('events')); ?>">
                        <i class="fas fa-calendar-alt"></i> <span><?php echo e(__('Events')); ?></span>
                    </a>
                </li>
            <?php endif; ?>
            <?php if(Auth::user()->hasRole('admin')): ?>
            <li class="<?php echo e(request()->is('app-user*') ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(url('app-user')); ?>">
                    <i class="fas fa-users"></i> <span><?php echo e(__('App Users')); ?></span>
                </a>
            </li>
            <?php endif; ?>
            <?php if(!Auth::user()->hasRole('Organizer')): ?>
            <li class="<?php echo e(request()->is('wallet-transactions*') ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(route('allTransactions')); ?>">
                    <i class="fas fa-wallet"></i><span><?php echo e(__('Wallet Transactions')); ?></span>
                </a>
            </li>
            <?php endif; ?>
            <?php if(Auth::user()->hasRole('Organizer')): ?>
                <li class="<?php echo e(request()->is('scanner*') ? 'active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(url('scanner')); ?>">
                        <i class="fas fa-id-card"></i> <span><?php echo e(__('Scanner')); ?></span>
                    </a>
                </li>
            <?php endif; ?>
            <?php if(Auth::user()->hasRole('Organizer')): ?>
                <li class="<?php echo e(request()->is('ticket-scanner*') ? 'active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(url('ticket-scanner')); ?>">
                        <i class="fas fa-qrcode"></i> <span><?php echo e(__('Ticket Scanner')); ?></span>
                    </a>
                </li>
            <?php endif; ?>
            <?php if(Auth::user()->hasRole('Organizer')): ?>
                <li class="<?php echo e(request()->is('/organization/income') ? 'active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(url('/organization/income')); ?>">
                        <i class="fa-solid fa-money-bill-wave"></i> <span><?php echo e(__('Income')); ?></span>
                    </a>
                </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('blog_access')): ?>
                <li class="<?php echo e(request()->is('blog*') ? 'active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(url('blog')); ?>">
                        <i class="fas fa-file-alt"></i><span><?php echo e(__('Blog')); ?></span>
                    </a>
                </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('coupon_access')): ?>
                <li class="<?php echo e(request()->is('coupon*') ? 'active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(url('coupon')); ?>">
                        <i class="fas fa-tags"></i> <span><?php echo e(__('Coupon')); ?></span>
                    </a>
                </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('banner_access')): ?>
                <li class="<?php echo e(request()->is('banner*') ? 'active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(url('banner')); ?>">
                        <i class="fas fa-images"></i><span><?php echo e(__('Banner')); ?></span>
                    </a>
                </li>
            <?php endif; ?>
            <li class="<?php echo e(request()->is('user-review') ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(url('user-review')); ?>">
                    <i class="fas fa-star"></i> <span><?php echo e(__('Review')); ?></span>
                </a>
            </li>
            
            <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
                <li class="<?php echo e(request()->is('event-review') ? 'active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(url('event-review')); ?>">
                        <i class="fas fa  fa-flag"></i> <span><?php echo e(__('Reported Events')); ?></span>
                    </a>
                </li>
            <?php endif; ?>
            <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin_report')): ?>
                    <li class="nav-item dropdown <?php echo e(request()->is('admin-report*') ? 'active' : ''); ?>">
                        <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i class="fas fa-chart-bar"></i>
                            <span><?php echo e(__('Reports')); ?></span></a>
                        <ul class="dropdown-menu">
                            <li><a class="nav-link" href="<?php echo e(url('admin-report/customer')); ?>"><?php echo e(__('Customer Report')); ?></a>
                            </li>
                            <li><a class="nav-link"
                                    href="<?php echo e(url('admin-report/organization')); ?>"><?php echo e(__('Organization Report')); ?></a></li>
                            <li><a class="nav-link" href="<?php echo e(url('admin-report/revenue')); ?>"><?php echo e(__('Revenue Report')); ?></a>
                            </li>
                            <li><a class="nav-link"
                                    href="<?php echo e(url('admin-report/settlement')); ?>"><?php echo e(__('Settlement Report')); ?></a></li>

                        </ul>
                    </li>
                <?php endif; ?>
            <?php endif; ?>
            <?php
                $bankModule = \App\Models\Module::where('module','BankPayout')->first();
            ?>
            <?php if($bankModule->is_enable == 1 && $bankModule->is_install == 1): ?>
                <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
                    <li class="<?php echo e(request()->is('bank-details') ? 'active' : ''); ?>">
                        <a class="nav-link" href="<?php echo e(url('bank-details')); ?>">
                            <i class="fa-solid fa-building-columns"></i><span><?php echo e(__('Bank Details')); ?></span>
                        </a>
                    </li>
                <?php endif; ?>
            <?php endif; ?>
            <?php if(auth()->check() && auth()->user()->hasRole('Organizer')): ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('organization_report')): ?>
                    <li class="nav-item dropdown <?php echo e(request()->is('organization-report*') ? 'active' : ''); ?>">
                        <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i
                                class="fas fa-chart-bar"></i>
                            <span><?php echo e(__('Reports')); ?></span></a>
                        <ul class="dropdown-menu">
                            <li><a class="nav-link"
                                    href="<?php echo e(url('organization-report/customer')); ?>"><?php echo e(__('Customer Report')); ?></a></li>
                            <li><a class="nav-link"
                                    href="<?php echo e(url('organization-report/orders')); ?>"><?php echo e(__('Orders Report')); ?></a></li>
                            <li><a class="nav-link"
                                    href="<?php echo e(url('organization-report/revenue')); ?>"><?php echo e(__('Revenue Report')); ?></a></li>
                        </ul>
                    </li>
                <?php endif; ?>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('notification_template_access')): ?>
                <li class="<?php echo e(request()->is('notification-template*') ? 'active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(url('notification-template')); ?>">
                        <i class="fas fa-bell"></i><span><?php echo e(__('Notification Template')); ?></span>
                    </a>
                </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('tax_access')): ?>
                <li class="<?php echo e(request()->is('tax*') ? 'active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(url('tax')); ?>">
                        <i class="fas fa-hand-holding-usd"></i><span><?php echo e(__('Tax')); ?></span>
                    </a>
                </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('feedback_access')): ?>
                <li class="<?php echo e(request()->is('feedback*') ? 'active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(url('feedback')); ?>">
                        <i class="fas fa-comments"></i><span><?php echo e(__('Feedback')); ?></span>
                    </a>
                </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('faq_access')): ?>
                <li class="<?php echo e(request()->is('faq*') ? 'active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(url('faq')); ?>">
                        <i class="fas fa-question-circle"></i><span><?php echo e(__('FAQs')); ?></span>
                    </a>
                </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('language_access')): ?>
                <li class="<?php echo e(request()->is('language*') ? 'active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(url('language')); ?>">
                        <i class="fas fa-language"></i><span><?php echo e(__('Language')); ?></span>
                    </a>
                </li>
            <?php endif; ?>
            <?php if(Auth::user()->hasRole('admin')): ?>
                <li class="<?php echo e(request()->is('admin-setting') ? 'active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(url('admin-setting')); ?>">
                        <i class="fas fa-cogs"></i><span><?php echo e(__('Setting')); ?></span>
                    </a>
                </li>
            <?php endif; ?>
            <?php if(Auth::user()->hasRole('Organizer')): ?>
                <li class="<?php echo e(request()->is('organizer-setting') ? 'active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(url('organizer-setting')); ?>">
                        <i class="fas fa-cogs"></i><span><?php echo e(__('Setting')); ?></span>
                    </a>
                </li>
            <?php endif; ?>
            <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('module_access')): ?>
                    <li class="<?php echo e(request()->is('module*') ? 'active' : ''); ?>">
                        <a class="nav-link" href="<?php echo e(url('module')); ?>">
                            <i class="fas fa-tasks"></i><span><?php echo e(__('Module')); ?></span>
                        </a>
                    </li>
                <?php endif; ?>
            <?php endif; ?>
            <?php if($bankModule->is_enable == 1 && $bankModule->is_install == 1): ?>
                <?php if(auth()->check() && auth()->user()->hasRole('Organizer')): ?>
                    <li class="<?php echo e(request()->is('bank-details') ? 'active' : ''); ?>">
                        <a class="nav-link" href="<?php echo e(url('bank-details')); ?>">
                            <i class="fa-solid fa-building-columns"></i><span><?php echo e(__('Bank Details')); ?></span>
                        </a>
                    </li>
                <?php endif; ?>
            <?php endif; ?>
            <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($module->is_install && $module->is_enable === 1): ?>
                    <?php if($module->module === 'Seatmap'): ?>
                        <li class="">
                            <a class="nav-link" href="<?php echo e(url('seatmap/index')); ?>">
                                <i class="fas fa-wheelchair"></i><span><?php echo e(__($module->module)); ?></span>
                            </a>
                        </li>
                    <?php endif; ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <li class="menu-header mt-4"><?php echo e(__('Account')); ?></li>
            <li>
                <a class="nav-link text-danger" href="<?php echo e(route('logout')); ?>" 
                   onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                    <i class="fas fa-sign-out-alt"></i> <span><?php echo e(__('Logout')); ?></span>
                </a>
            </li>
            
            
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                <?php echo csrf_field(); ?>
            </form>
        </ul>
    </aside>
</div>
<?php /**PATH /home/u726836945/domains/starrtix.com/public_html/app/resources/views/admin/layout/sidebar.blade.php ENDPATH**/ ?>