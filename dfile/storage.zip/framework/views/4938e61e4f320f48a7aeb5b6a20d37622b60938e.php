<?php $__env->startSection('content'); ?>
    <section class="section">
        <?php echo $__env->make('admin.layout.breadcrumbs', [
            'title' => __('Events'),
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="section-body">

            <div class="row">
                <div class="col-12">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?php echo e(session('status')); ?>

                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="row mb-4 mt-2">
                                <div class="col-lg-8">
                                    <h2 class="section-title mt-0"> <?php echo e(__('All Events')); ?></h2>
                                </div>
                                <div class="col-lg-4 text-right">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('event_create')): ?>
                                        <button class="btn btn-primary add-button"><a href="<?php echo e(url('event/create')); ?>"><i
                                                    class="fas fa-plus"></i> <?php echo e(__('Add New')); ?></a></button>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="table-responsive">
                                <table class="table" id="report_table">
                                    <thead>
                                        <tr>
                                            <th></th>
                                            <th><?php echo e(__('Image')); ?></th>
                                            <th><?php echo e(__('Name')); ?></th>
                                            <th><?php echo e(__('Start Date')); ?></th>
                                            <th><?php echo e(__('Number of People')); ?></th>
                                            <th><?php echo e(__('Category')); ?></th>
                                            <?php if(Auth::user()->hasRole('admin')): ?>
                                                <th><?php echo e(__('Organization')); ?></th>
                                            <?php endif; ?>
                                            <th><?php echo e(__('Status')); ?></th>
                                            <?php if(Gate::check('event_edit') || Gate::check('event_delete')): ?>
                                                <th><?php echo e(__('Action')); ?></th>
                                            <?php endif; ?>
                                            <?php if(Gate::check('ticket_access')): ?>
                                                <th><?php echo e(__('Tickets')); ?></th>
                                            <?php endif; ?>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td></td>
                                                <th> <img class="table-img"
                                                        src="<?php echo e(url('images/upload/' . $item->image)); ?>">
                                                </th>
                                                <td>
                                                    <h6 class="mb-0"><?php echo e($item->name); ?></h6>
                                                    <p class="mb-0"><?php echo e($item->address); ?> </p>
                                                </td>
                                                <td>
                                                    <p class="mb-0">
                                                        <?php echo e(Carbon\Carbon::parse($item->start_time)->format('Y-m-d h:i a') . ', ' . $item->start_time->format('l')); ?>

                                                    </p>
                                                </td>
                                                <td><?php echo e($item->people); ?></td>
                                                <td><?php echo e($item->category->name); ?></td>
                                                <?php if(Auth::user()->hasRole('admin')): ?>
                                                    <td><?php echo e($item->organization->first_name . ' ' . $item->organization->last_name); ?>

                                                    </td>
                                                <?php endif; ?>
                                                <td>
                                                    <h5><span
                                                            class="badge <?php echo e($item->status == '1' ? 'badge-success' : 'badge-warning'); ?>  m-1"><?php echo e($item->status == '1' ? 'Publish' : 'Draft'); ?></span>
                                                    </h5>
                                                </td>
                                                <?php if(Gate::check('event_edit') || Gate::check('event_delete')): ?>
                                                    <td>
                                                        <a href="<?php echo e(url('/events_details', $item->id)); ?>" title="View Event"
                                                            class="btn-icon"><i class="fas fa-eye"></i></a>
                                                        <a href="<?php echo e(url('event-gallery/' . $item->id)); ?>"
                                                            title="Event Gallery" class="btn-icon"><i
                                                                class="far fa-images"></i></a>
                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('event_edit')): ?>
                                                            <a href="<?php echo e(route('events.edit', $item->id)); ?>" title="Edit Event"
                                                                class="btn-icon"><i class="fas fa-edit"></i></a>
                                                        <?php endif; ?>
                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('event_delete')): ?>
                                                            <a href="#"
                                                                onclick="deleteData('events','<?php echo e($item->id); ?>');"
                                                                title="Delete Event" class="btn-icon text-danger"><i
                                                                    class="fas fa-trash-alt text-danger"></i></a>
                                                        <?php endif; ?>
                                                    </td>
                                                <?php endif; ?>
                                                <?php if(Gate::check('ticket_access')): ?>
                                                    <td>
                                                        <a href="<?php echo e(url($item->id . '/' . Str::slug($item->name) . '/tickets')); ?>"
                                                            class=" btn btn-primary"><?php echo e(__('Manage Tickets')); ?></a>
                                                    </td>
                                                <?php endif; ?>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u726836945/domains/starrtix.com/public_html/app/resources/views/admin/event/index.blade.php ENDPATH**/ ?>