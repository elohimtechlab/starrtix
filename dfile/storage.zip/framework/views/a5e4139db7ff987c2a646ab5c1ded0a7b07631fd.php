<?php $__env->startSection('content'); ?>
    <section class="section">
        <?php echo $__env->make('admin.layout.breadcrumbs', [
            'title' => __('Scanner'),
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="section-body">
            <div class="row">
                <div class="col-12">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?php echo e(session('status')); ?>

                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="row mb-4 mt-2">
                                <div class="col-lg-8">
                                    <h2 class="section-title mt-0"> <?php echo e(__('View Scanner')); ?></h2>
                                </div>
                                <div class="col-lg-4 text-right">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('scanner_create')): ?>
                                        <button class="btn btn-primary add-button"><a href="<?php echo e(url('scanner/create')); ?>"><i
                                                    class="fas fa-plus"></i> <?php echo e(__('Add New')); ?></a></button>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="table-responsive">
                                <table class="table" id="report_table">
                                    <thead>
                                        <tr>
                                            <th></th>
                                            <th><?php echo e(__('Name')); ?></th>
                                            <th><?php echo e(__('Total events')); ?></th>
                                            <th><?php echo e(__('Status')); ?></th>
                                            <th><?php echo e(__('Action')); ?></th>

                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $scanners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td></td>
                                                <td>
                                                    <div class="media">
                                                        <img alt="image" class="mr-3 avatar"
                                                            src="<?php echo e(url('images/upload/' . $item->image)); ?>">
                                                        <div class="media-body">
                                                            <div class="media-title mb-0">
                                                                <?php echo e($item->first_name . ' ' . $item->last_name); ?>

                                                            </div>
                                                            <div class="media-description text-muted"> <?php echo e($item->email); ?>

                                                            </div>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td><?php echo e($item->total_event); ?></td>
                                                <td><span
                                                        class="badge <?php echo e($item->status == 1 ? 'badge-success' : 'badge-danger'); ?> badge-primary">
                                                        <?php echo e($item->status == 1 ? 'Active' : 'Inactive'); ?></span></td>
                                                <td>
                                                    <?php if($item->status == '0'): ?>
                                                        <a href="<?php echo e(url('block-scanner/' . $item->id)); ?>"
                                                            title="Unblock <?php echo e($item->name); ?>"
                                                            class="btn-icon text-success"><i
                                                                class="fas fa-unlock-alt"></i></a>
                                                    <?php else: ?>
                                                        <a href="<?php echo e(url('block-scanner/' . $item->id)); ?>"
                                                            title="Block <?php echo e($item->name); ?>"
                                                            class="btn-icon text-danger"><i
                                                                class="fas fa-ban text-danger"></i></a>
                                                    <?php endif; ?>
                                                </td>

                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u726836945/domains/starrtix.com/public_html/app/resources/views/admin/scanner/index.blade.php ENDPATH**/ ?>