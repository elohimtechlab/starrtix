<div class="navbar-bg"></div>

<nav class="navbar navbar-expand-lg main-navbar">

    <form class="form-inline mr-auto">
        <ul class="navbar-nav mr-3">
            <li><a href="#" data-toggle="sidebar" class="nav-link nav-link-lg"><i class="fas fa-bars"></i></a></li>
        </ul>
    </form>


    <ul class="navbar-nav navbar-right">
        <?php if(Auth::user()->hasRole('Organizer')): ?>
            <li>
                <?php
                    $notification = \App\Models\Notification::where([['status', 1],['organizer_id', Auth::user()->id]])
                        ->orderBy('id', 'DESC')
                        ->get();
                ?>

                <?php if(count($notification) == 0): ?>
                    <a href="#" data-toggle="dropdown" class="nav-link notification-toggle nav-link-lg"><i
                            class="far fa-bell"></i></a>
                <?php else: ?>
                    <a href="#" data-toggle="dropdown" class="nav-link notification-toggle nav-link-lg beep"><i
                            class="far fa-bell"></i></a>
                <?php endif; ?>

                <div class="dropdown-menu dropdown-list dropdown-menu-right">
                    <div class="dropdown-header"><?php echo e(__('Notifications')); ?>

                        <a class="text-decoration-none float-right"
                            href="<?php echo e(url('markAllAsRead')); ?>"><?php echo e(__('Mark All As Read')); ?></a>
                        <div class="float-right">
                        </div>
                    </div>

                    <?php if(count($notification) == 0): ?>
                        <div class="dropdown-list-content dropdown-list-icons">
                            <a href="#" class="dropdown-item">
                                <div class="dropdown-item-desc">
                                    <h6><?php echo e(__('No notification found')); ?></h6>
                                </div>
                            </a>
                        </div>
                    <?php else: ?>
                        <div class="dropdown-list-content dropdown-list-icons">
                            <?php $__currentLoopData = $notification; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($item->user != null): ?>
                                    <?php if($loop->iteration <= 3): ?>
                                        <a href="#" class="dropdown-item">
                                            <div class="dropdown-item-icon bg-danger text-white">
                                                <img class="avatar"
                                                    src="<?php echo e(url('images/upload/' . $item->user->image)); ?>">
                                            </div>
                                            <div class="dropdown-item-desc">
                                                <?php echo e($item->message); ?>

                                                <div class="time"><?php echo e($item->created_at->diffForHumans()); ?></div>
                                            </div>
                                        </a>
                                    <?php endif; ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="dropdown-footer text-center">
                            <a href="<?php echo e(url('notification')); ?>"><?php echo e(__('View All')); ?> <i
                                    class="fas fa-chevron-right"></i></a>
                        </div>
                    <?php endif; ?>
                </div>
            </li>
        <?php endif; ?>
        
        <?php if(env('APP_DEBUG')): ?>
        <button class="btn btn-danger shadow-none" disabled>⚠ <?php echo e(__('Debug Mode is ON')); ?></button>
        <?php endif; ?>
        <?php $lang = session('locale') == null ? 'English' : session('locale'); ?>
        <?php
            $languages = \App\Models\Language::where('status', 1)->get();
        ?>
        <li class="dropdown"><a href="#" data-toggle="dropdown"
                class="nav-link dropdown-toggle nav-link-lg nav-link-user">
                <img src="<?php echo e(url('images/upload/' . $lang . '.png')); ?>" class="mr-1 flag-icon">
                <div class="d-sm-none d-lg-inline-block"></div>
            </a>
            <div class="dropdown-menu dropdown-menu-right">
                <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(url('change-language/' . $language->name)); ?>" class="dropdown-item has-icon">
                        <img src="<?php echo e(url('images/upload/' . $language->image)); ?>" class="mr-2 flag-icon">
                        <?php echo e($language->name); ?>

                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </li>
        <li class="dropdown"><a href="#" data-toggle="dropdown"
                class="nav-link dropdown-toggle nav-link-lg nav-link-user">
                <img alt="image" src="<?php echo e(url('images/upload/' . Auth::user()->image)); ?>"
                    class="rounded-circle mr-1">
                <div class="d-sm-none d-lg-inline-block"><?php echo e(Auth::user()->first_name ." ". Auth::user()->last_name); ?></div>
            </a>
            <div class="dropdown-menu dropdown-menu-right">
                <div class="dropdown-title"><?php echo e(__('Welcome')); ?> <?php echo e(Auth::user()->first_name ." ". Auth::user()->last_name); ?>!</div>
                <a href="<?php echo e(url('profile')); ?>" class="dropdown-item has-icon">
                    <i class="far fa-user"></i> <?php echo e(__('Profile')); ?>

                </a>
                <?php if(Auth::user()->hasRole('admin')): ?>
                    <a href="<?php echo e(url('admin-setting')); ?>" class="dropdown-item has-icon">
                        <i class="fas fa-cog"></i> <?php echo e(__('Settings')); ?>

                    </a>
                    <a href="<?php echo e(url('license-setting')); ?>" class="dropdown-item has-icon">
                        <i class="fas fa-shield-alt"></i> <?php echo e(__('License Setting')); ?>

                    </a>
                <?php endif; ?>
                        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />
                        <a class="dropdown-item" type="button">

                            <button class=" btn btn-outline-danger" id=check name="check">    <i class="fa-solid fa-right-from-bracket"></i> <?php echo e(__('Logout')); ?></button>
                        </a>
                        <script>
                            document.getElementById("check").addEventListener('click', function() {
                                Swal.fire({
                                    title: 'Are you sure to logout!!',
                                    icon: 'warning',
                                    showCancelButton: true,
                                    confirmButtonColor: '#3085d6',
                                    cancelButtonColor: '#d33',
                                    confirmButtonText: 'Yes',
                                    allowOutsideClick: false
                                }).then((result) => {
                                    if (result.isConfirmed) {
                                        // Submit the hidden logout form instead of using GET request
                                        document.getElementById('admin-logout-form').submit();
                                    }
                                })
                            });
                        </script>
                        
                        
                        <form id="admin-logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>
            </div>
        </li>
    </ul>
    <?php
    if (App::isDownForMaintenance()) {
    ?>
    <div class="alert alert-danger maintenance">
        Maintenance mode is enabled!
    </div>

    <?php
    } else {
    ?>

    <?php
    }
     ?>
</nav>
<?php /**PATH /home/u726836945/domains/starrtix.com/public_html/app/resources/views/admin/layout/header.blade.php ENDPATH**/ ?>