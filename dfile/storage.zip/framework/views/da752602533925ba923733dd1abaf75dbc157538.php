<?php $__env->startSection('content'); ?>
    <?php
        $logo = \App\Models\Setting::find(1)->logo;
    ?>
    <section class="section">
        <div class="d-flex flex-wrap align-items-stretch">
            <div class="col-lg-4 col-md-6 col-12 order-lg-1 min-vh-100 order-2 bg-white">
                <div class="p-4 m-3 w-10 h-10">
                    <img src="<?php echo e($logo ? asset('/images/upload/' . $logo) : asset('/images/logo.png')); ?>" alt="logo"
                         height="50px" class="mb-4 mt-2 object-contain w-auto">
                    <h4 class="text-dark font-weight-normal mb-4"><?php echo e(__('Welcome to ')); ?><span
                            class="font-weight-bold"><?php echo e(\App\Models\Setting::find(1)->app_name); ?></span></h4>
                    <form method="POST" action="<?php echo e(url('admin/login')); ?>" class="needs-validation" novalidate="">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="email"><?php echo e(__('Email')); ?></label>
                            <input id="email" type="email" class="form-control" name="email" tabindex="1" required
                                autofocus>
                            <?php if($errors->has('email')): ?>
                                <div class="invalid-feedback">
                                    <strong><?php echo e($errors->first('email')); ?></strong>
                                </div>
                            <?php endif; ?>
                            <?php if(Session::has('error_msg')): ?>
                                <span class="invalid-feedback" style="display: block;">
                                    <strong><?php echo e(Session::get('error_msg')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <div class="d-block">
                                <label for="password" class="control-label"><?php echo e(__('Password')); ?></label>
                            </div>
                            <input id="password" type="password" class="form-control" name="password" tabindex="2"
                                required>
                            <?php if($errors->has('password')): ?>
                                <div class="invalid-feedback">
                                    <strong><?php echo e($errors->first('password')); ?></strong>
                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <div class="custom-control custom-checkbox">
                                <input type="checkbox" name="remember" class="custom-control-input" tabindex="3"
                                    id="remember-me">
                                <label class="custom-control-label" for="remember-me"><?php echo e(__('Remember Me')); ?></label>
                            </div>
                        </div>

                        <div class="form-group text-right">
                            <button type="submit" class="btn btn-primary btn-lg btn-icon icon-right" tabindex="4">
                                <?php echo e(__('Login')); ?>

                            </button>
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-lg-8 col-12 order-lg-2 order-1 min-vh-100 background-walk-y position-relative overlay-gradient-bottom"
                data-background="<?php echo e(url('/images/auth_image.png')); ?>">
                <div class="absolute-bottom-left index-2">
                    <div class="text-light p-5 pb-2">
                        <div class="mb-5 pb-3">
                            <h1 class="mb-2 display-4 font-weight-bold"><?php echo e(__('Welcome')); ?></h1>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u726836945/domains/starrtix.com/public_html/app/resources/views/auth/login.blade.php ENDPATH**/ ?>