<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta charset="utf-8">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        crossorigin="anonymous">
</head>

<body>
    <?php $primary_color = \App\Models\Setting::find(1)->primary_color; ?>

    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <style>
        .margintop {
            margin-top: 20px;
        }

        table#custometable {
            border: 0ch !important;
            width: 50%;

        }

        #custometable td {
            padding: 5px;
            border: 0px;
        }

        .specialchar {
            font-family: "DejaVu Sans Mono",
                monospace;
        }

        :root {
            --primary_color: <?php echo e($primary_color); ?>;
            --light_primary_color: <?php echo e($primary_color . '1a'); ?>;
            --middle_light_primary_color: <?php echo e($primary_color . '85'); ?>;
        }
    </style>
    <div class="main-wrapper">
        <div class="p-5">
            <div class="section-body">
                <div class="invoice">
                    <div class="invoice-print">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="invoice-title">

                                    <h3 style="color: #6c757d"><?php echo e(__('Order')); ?> <?php echo e($order->order_id); ?></h3>
                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-md-6 text-left">
                                        <address>
                                            <strong style="color: #6c757d"><?php echo e(__('Event')); ?>:</strong>
                                        </address>
                                        <div class="media">
                                            <div class="row">

                                                <div class="col-md-12">

                                                    <img alt="image" class="mr-3"
                                                        src="<?php echo e(public_path('images/upload/' . $order->event->image)); ?>"
                                                        width="80" height="80">
                                                    <div style="margin-left: 420px">
                                                        <?php $__currentLoopData = $order->ticket_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php
                                                            $qr = QrCode::format('png')
                                                                ->size(150)
                                                                ->generate($item->ticket_number);
                                                            ?>
                                                            <img src="data:image/png;base64,<?php echo e(base64_encode($qr)); ?>"
                                                                alt="QR Code">
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="media-body">
                                            <div class="media-title mb-0">
                                                <?php echo e($order->event->name); ?>

                                            </div>
                                            <div class="media-description text-muted">
                                                <?php echo e($order->event->start_time->format('l') . ', ' . $order->event->start_time->format('d M Y')); ?>

                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>


                            <div class="row">

                                <div class="col-md-6 text-md-right" style="margin-left: 12px">
                                    <address>
                                        <strong><?php echo e(__('Organizer')); ?>:</strong><br>
                                        <div style="color: #6c757d">
                                            <?php echo e($order->organization->first_name . ' ' . $order->organization->last_name); ?><br>
                                            <?php echo e($order->organization->email); ?><br>
                                            <?php echo e($order->organization->country); ?>

                                        </div>

                                    </address>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6" style="margin-left: 12px">
                                    <address>
                                        <strong><?php echo e(__('Attendee')); ?>:</strong><br>
                                        <div style="color: #6c757d">
                                            <?php echo e($order->customer->name . ' ' . $order->customer->last_name); ?><br>
                                            <?php echo e($order->customer->email); ?><br>
                                        </div>
                                    </address>
                                </div>
                                <div class="col-md-6 text-md-right" style="margin-left: 12px">
                                    <address>
                                        <strong><?php echo e(__('Order Date')); ?>:</strong><br>
                                        <div style="color: #6c757d">
                                            <?php echo e($order->created_at->format('d F, Y')); ?><br><br>
                                        </div>
                                    </address>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-12 ">
                            <div class="section-title"><?php echo e(__('Order Summary')); ?></div>
                            <div class="table-responsive">
                                <table class="table table-striped table-hover table-md border-0">
                                    <th>#</th>
                                    <th class="text-center "><?php echo e(__('Ticket Name')); ?></th>
                                    <th class="text-center"><?php echo e(__('Ticket Number')); ?></th>
                                    <th class="text-center"><?php echo e(__('Price')); ?></th>
                                    <?php $__currentLoopData = $order->ticket_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><small><?php echo e($loop->iteration); ?></small></td>
                                            <td class="text-center"><small><?php echo e($order->ticket->name); ?></small></td>
                                            <td class="text-center"><small><?php echo e($item->ticket_number); ?></small></td>
                                            <td class="text-center specialchar">
                                                <small><?php echo e($currency . $order->ticket->price); ?></small>
                                            </td>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </table>
                            </div>
                        </div>
                    </div>
                    <?php if($order->payment_type != 'FREE'): ?>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="section-title"><?php echo e(__('Payment Method')); ?></div>
                                <address>
                                    <strong><?php echo e($order->payment_type); ?></strong><br>
                                    <span
                                        class="badge mt-1 mb-1 <?php echo e($order->payment_status == 1 ? 'badge-success' : 'badge-warning'); ?>"><?php echo e($order->payment_status == 1 ? __('Paid') : __('Waiting')); ?></span><br>
                                    <?php echo e(__('Token:')); ?>

                                    <?php echo e($order->payment_token == null ? '-' : $order->payment_token); ?><br>
                                </address>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">

                                <table class="table" id="custometable"
                                    style="margin-bottom: 1rem;color: #212529;border-collapse: collapse; margin-left:45%; margin-top:-105px">
                                    <tr>
                                        <td class="small">
                                            <?php echo e(__('Subtotal')); ?></td>
                                        <td class="small specialchar ">
                                            <?php echo e($currency . ($order->payment + $order->coupon_discount - $order->tax)); ?>

                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="small ">
                                            <?php echo e(__('Coupon Discount')); ?></td>
                                        <td class="small specialchar ">
                                            (-)
                                            <?php echo e($currency . $order->coupon_discount); ?>

                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="small">
                                            <?php echo e(__('Total')); ?></td>
                                        <td class="small specialchar">
                                            <?php echo e($currency . $order->payment); ?>

                                        </td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

</body>

</html>
<?php /**PATH /home/u726836945/domains/starrtix.com/public_html/app/resources/views/ticketmail.blade.php ENDPATH**/ ?>