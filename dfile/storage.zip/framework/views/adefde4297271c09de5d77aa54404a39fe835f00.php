<?php echo e('Event Ticket'); ?>

<?php /**PATH /home/u726836945/domains/starrtix.com/public_html/app/resources/views/mail.blade.php ENDPATH**/ ?>