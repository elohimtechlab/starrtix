<footer class="main-footer">
    <div class="footer-left">
    <?php echo e(\App\Models\Setting::find(1)->footertext); ?>

    </div>
    <div class="footer-right">
      <?php echo e(\App\Models\Setting::find(1)->app_version); ?>

    </div>
</footer>
<?php /**PATH /home/u726836945/domains/starrtix.com/public_html/app/resources/views/admin/layout/footer.blade.php ENDPATH**/ ?>