<!DOCTYPE html>
<html lang="en">

<head>
    <?php
        $favicon = \App\Models\Setting::find(1)->favicon;
    ?>
    <meta charset="utf-8">
    <link href="<?php echo e($favicon ? url('images/upload/' . $favicon) : asset('/images/logo.png')); ?>" rel="icon"
        type="image/png">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title><?php echo e(\App\Models\Setting::find(1)->app_name); ?> | <?php echo $__env->yieldContent('title'); ?></title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link href="<?php echo e(asset('css/app.css')); ?>?v=<?php echo e(time()); ?>" rel="stylesheet">
    <input type="hidden" name="base_url" id="base_url" value="<?php echo e(url('/')); ?>">
    <link href="<?php echo e(asset('css/select2.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/custom.css')); ?>" rel="stylesheet">
    <?php echo JsonLdMulti::generate(); ?>

    <?php echo SEOMeta::generate(); ?>

    <?php echo OpenGraph::generate(); ?>

    <?php echo Twitter::generate(); ?>

    <?php echo JsonLd::generate(); ?>

    <!-- Favicons -->
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" />
    <!-- Vendor CSS Files -->
    <link href="<?php echo e(url('frontend/css/ionicons.min.css')); ?>" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.7/css/select2.min.css" rel="stylesheet" />
    <link href="<?php echo e(url('frontend/css/animate.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(url('frontend/css/font-awesome.min.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <link href="<?php echo e(url('frontend/css/owl.carousel.min.css')); ?>" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <script type="text/javascript" src="https://js.stripe.com/v3/"></script>
    <!-- Template Main CSS File -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"
        integrity="sha512-CNgIRecGo7nphbeZ04Sc13ka07paqdeTu0WR1IM4kNcpmBAUSHSQX0FslNhTDadL4O5SAGapGt4FodqL8My0mA=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <?php if(session('direction') == 'rtl'): ?>
        <link rel="stylesheet" href="<?php echo e(url('frontend/css/rtl.css')); ?>">
    <?php endif; ?>
</head>

<body>
    <div class="lds-ripple">
        <div></div>
        <div></div>
    </div>

    <div id="app">


        <?php $primary_color = \App\Models\Setting::find(1)->primary_color; ?>

        <style>
            :root {
                --primary_color: <?php echo e($primary_color); ?>;
                --light_primary_color: <?php echo e($primary_color . '1a'); ?>;
                --profile_primary_color: <?php echo e($primary_color . '52'); ?>;
                --middle_light_primary_color: <?php echo e($primary_color . '85'); ?>;
                /* Custom color scheme */
                --secondary_color: #f7941d;
                --footer_color: #334389;
                --light_secondary_color: #f7941d1a;
                --light_footer_color: #3343891a;
            }

            .bg-primary {
                --tw-bg-opacity: 1;
                background-color: var(--primary_color);
            }

            .bg-secondary {
                --tw-bg-opacity: 1;
                background-color: var(--secondary_color);
            }

            .bg-footer {
                --tw-bg-opacity: 1;
                background-color: var(--footer_color);
            }

            .text-secondary {
                color: var(--secondary_color);
            }

            .text-footer {
                color: var(--footer_color);
            }

            .bg-primary-dark {
                --tw-bg-opacity: 1;
                background-color: var(--profile_primary_color);
                /* Use the profile_primary_color variable */
            }

            .navbar-nav>.active>a {
                color: var(--primary_color);
            }

            .text-primary {
                --tw-text-opacity: 1;
                color: var(--primary_color);
            }

            .border-primary {
                --tw-border-opacity: 1;
                border-color: var(--primary_color);
            }

            .carousel-indicators button[aria-current=true] {
                background: var(--primary_color) !important;
            }

            .profile button[aria-selected=true] {
                background: var(--primary_color) !important;
                color: #FFFFFF !important;
            }
        </style>

        <input type="hidden" name="currency" id="currency" value="<?php echo e($currency); ?>">
        <input type="hidden" name="default_lat" id="default_lat"
            value="<?php echo e(\App\Models\Setting::find(1)->default_lat); ?>">
        <input type="hidden" name="default_long" id="default_long"
            value="<?php echo e(\App\Models\Setting::find(1)->default_long); ?>">
        <div class="site-wrapper">
            <?php echo $__env->make('frontend.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="min-h-screen flex flex-col">
                <main class="flex-grow">
                    <?php echo $__env->yieldContent('content'); ?>
                </main>
                <footer class="mt-auto">
                    <?php echo $__env->make('frontend.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </footer>
            </div>
        </div>

        <script src="https://checkout.flutterwave.com/v3.js"></script>
        <script src="<?php echo e(url('frontend/js/jquery.min.js')); ?>"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.7/js/select2.min.js"></script>
        <script src="<?php echo e(url('frontend/js/jquery.easing.min.js')); ?>"></script>
        <script src="<?php echo e(url('frontend/js/validate.js')); ?>"></script>
        <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
        <script src="<?php echo e(url('frontend/js/owl.carousel.min.js')); ?>"></script>
        <script src="<?php echo e(url('frontend/js/scrollreveal.min.js')); ?>"></script>
        <script src="<?php echo e(url('frontend/js/map.js')); ?>"></script>

        <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
        <script src="https://checkout.flutterwave.com/v3.js"></script>
        <?php 
            $client_id = \App\Models\PaymentSetting::find(1)->paypalClientId;
            $cur = \App\Models\Setting::find(1)->currency;
            $map_key = \App\Models\Setting::find(1)->map_key;
        ?>
        <?php if($client_id != null): ?>
            <script src="https://www.paypal.com/sdk/js?client-id=<?php echo e($client_id); ?>&currency=<?php echo e($cur); ?>"
                data-namespace="paypal_sdk"></script>
        <?php endif; ?>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
        <script src="https://unpkg.com/flowbite@1.5.5/dist/flowbite.js"></script>
        <script src="<?php echo e(url('frontend/js/qrcode.min.js')); ?>"></script>
        <script src="<?php echo e(url('frontend/js/main.js')); ?>?v=<?php echo e(time()); ?>"></script>
        <script src="<?php echo e(url('frontend/js/custom.js')); ?>?v=<?php echo e(time()); ?>"></script>
        <script src="<?php echo e(url('js/custom.js')); ?>?v=<?php echo e(time()); ?>"></script>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.6.4/datepicker.min.js"></script>
        <script type="text/javascript" src="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>
        
        <!-- Fix for frontend header dropdown menu accessibility -->
        <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Fix dropdown menu accessibility
            const dropdownButtons = document.querySelectorAll('.dropdownScreenButton');
            
            dropdownButtons.forEach(function(button) {
                // Make the dropdown button area clickable
                button.style.cursor = 'pointer';
                
                // Add click event to toggle dropdown
                button.addEventListener('click', function(e) {
                    e.stopPropagation();
                    const dropdown = this.querySelector('.dropdownMenuClass');
                    if (dropdown) {
                        dropdown.classList.toggle('hidden');
                        
                        // Close other dropdowns
                        document.querySelectorAll('.dropdownMenuClass').forEach(function(otherDropdown) {
                            if (otherDropdown !== dropdown) {
                                otherDropdown.classList.add('hidden');
                            }
                        });
                    }
                });
            });
            
            // Close dropdown when clicking outside
            document.addEventListener('click', function(event) {
                const dropdowns = document.querySelectorAll('.dropdownMenuClass');
                dropdowns.forEach(function(dropdown) {
                    const dropdownContainer = dropdown.closest('.dropdownScreenButton');
                    if (dropdownContainer && !dropdownContainer.contains(event.target)) {
                        dropdown.classList.add('hidden');
                    }
                });
            });
            
            // Improve dropdown positioning and z-index
            const dropdowns = document.querySelectorAll('.dropdownMenuClass');
            dropdowns.forEach(function(dropdown) {
                dropdown.style.zIndex = '9999';
                dropdown.classList.remove('rigin-top-right'); // Fix typo
                dropdown.classList.add('origin-top-right');
            });
        });
        </script>
    </div>
</body>

</html>
<?php /**PATH /home/u726836945/domains/starrtix.com/public_html/app/resources/views/frontend/master.blade.php ENDPATH**/ ?>