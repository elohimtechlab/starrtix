<?php $__env->startSection('content'); ?>
    <section class="section">

        <?php echo $__env->make('admin.layout.breadcrumbs', [
            'title' => __('Setting'),
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



        <div class="section-body">

            <div class="row">

                <div class="col-lg-8">

                    <h2 class="section-title"> <?php echo e(__('Admin Setting')); ?></h2>

                </div>

                <div class="col-lg-4 text-right">

                </div>

            </div>



            <div class="row">

                <div class="col-12">

                    <?php if(session('status')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">

                            <?php echo e(session('status')); ?>


                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">

                                <span aria-hidden="true">&times;</span>

                            </button>

                        </div>
                    <?php endif; ?>

                </div>
                <div class="col-12">

                    <?php if(session('Exception')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">

                            <?php echo e(session('Exception')); ?>


                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">

                                <span aria-hidden="true">&times;</span>

                            </button>

                        </div>
                    <?php endif; ?>

                </div>
                <div class="col-lg-6">
                    <div class="card card-large-icons">
                        <div class="card-icon bg-primary text-white">
                            <i class="fas fa-solid fa-address-card"></i>
                        </div>
                        <div class="card-body">
                            <h4><?php echo e(__('About us')); ?></h4>
                            <p><?php echo e(__('Set your about us page details')); ?></p>
                            <a href="#about_us" aria-controls="SocialMediaLinks-setting" role="button"
                                data-toggle="collapse" class="card-cta" aria-expanded="false"><?php echo e(__('Change Setting')); ?> <i
                                    class="fas fa-chevron-right"></i>
                            </a>
                            <div class="collapse mt-3 " id="about_us">
                                <form action="<?php echo e(url('/about_us')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group row mb-4">
                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Name')); ?></label>
                                        <div class="col-sm-12 col-md-9">
                                            <input type="text" required name="name" placeholder="<?php echo e(__('Name')); ?>"
                                                value="<?php echo e($aboutUs ? $aboutUs->name : ''); ?>"
                                                class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="form-group row mb-4">
                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Email')); ?></label>
                                        <div class="col-sm-12 col-md-9">
                                            <input type="email" name="email" placeholder="<?php echo e(__('Email')); ?>"
                                                value="<?php echo e($aboutUs ? $aboutUs->email : ''); ?>"
                                                class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="form-group row mb-4">
                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Phone')); ?></label>
                                        <div class="col-sm-12 col-md-9">
                                            <input type="text" name="phone" placeholder="<?php echo e(__('Phone')); ?>"
                                                value="<?php echo e($aboutUs ? $aboutUs->phone : ''); ?>"
                                                class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="form-group row mb-4">
                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Address')); ?></label>
                                        <div class="col-sm-12 col-md-9">

                                            <textarea placeholder="<?php echo e(__('Address')); ?>" name="address" id="address" cols="30" rows="10"
                                                id="autocomplete" class="form-control <?php $__errorArgs = ['Pinterest'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e($aboutUs ? $aboutUs->address : ''); ?>

                                                </textarea>
                                            <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="form-group row mb-4">
                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Lat')); ?></label>
                                        <div class="col-sm-12 col-md-9">
                                            <input type="text" name="lat" placeholder="<?php echo e(__('Lat')); ?>"
                                                id="latitude" value="<?php echo e($aboutUs ? $aboutUs->lat : ''); ?>"
                                                class="form-control <?php $__errorArgs = ['lat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <?php $__errorArgs = ['lat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="form-group row mb-4">
                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Long')); ?></label>
                                        <div class="col-sm-12 col-md-9">
                                            <input type="text" name="long" placeholder="<?php echo e(__('Long')); ?>"
                                                id="longitude" value="<?php echo e($aboutUs ? $aboutUs->long : ''); ?>"
                                                class="form-control <?php $__errorArgs = ['long'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <?php $__errorArgs = ['long'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>

                                    <div class="form-group row mb-4">

                                        <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3"></label>

                                        <div class="col-sm-12 col-md-7">

                                            <button type="submit"
                                                class="btn btn-primary demo-button"><?php echo e(__('Save')); ?></button>

                                        </div>

                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="card card-large-icons">
                        <div class="card-icon bg-primary text-white">
                            <i class="fas fa-solid fa-link"></i>
                        </div>
                        <div class="card-body">
                            <h4><?php echo e(__('Social Media Links')); ?></h4>
                            <p><?php echo e(__('Social Media Links')); ?></p>
                            <a href="#SocialMediaLinks-setting" aria-controls="SocialMediaLinks-setting" role="button"
                                data-toggle="collapse" class="card-cta" aria-expanded="false"><?php echo e(__('Change Setting')); ?>

                                <i class="fas fa-chevron-right"></i>
                            </a>
                            <div class="collapse mt-3 " id="SocialMediaLinks-setting">
                                <form action="<?php echo e(url('socialmedialinks')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group row mb-4">
                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Instagram')); ?></label>
                                        <div class="col-sm-12 col-md-9">
                                            <input type="text" required name="Instagram"
                                                placeholder="<?php echo e(__('Instagram Link')); ?>"
                                                value="<?php echo e($setting->Instagram); ?>"
                                                class="form-control <?php $__errorArgs = ['instagram'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <?php $__errorArgs = ['instagram'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="form-group row mb-4">
                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Facebook')); ?></label>
                                        <div class="col-sm-12 col-md-9">
                                            <input type="text" name="Facebook"
                                                placeholder="<?php echo e(__('Facebook Link')); ?>" value="<?php echo e($setting->Facebook); ?>"
                                                class="form-control <?php $__errorArgs = ['Facebook'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <?php $__errorArgs = ['Facebook'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="form-group row mb-4">
                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Twitter')); ?></label>
                                        <div class="col-sm-12 col-md-9">
                                            <input type="text" name="Twitter" placeholder="<?php echo e(__('Twitter Link')); ?>"
                                                value="<?php echo e($setting->Twitter); ?>"
                                                class="form-control <?php $__errorArgs = ['Twitter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <?php $__errorArgs = ['Twitter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="form-group row mb-4">
                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Pinterest')); ?></label>
                                        <div class="col-sm-12 col-md-9">
                                            <input type="text" name="Pinterest"
                                                placeholder="<?php echo e(__('Pinterest Link')); ?>"
                                                value="<?php echo e($setting->Pinterest); ?>"
                                                class="form-control <?php $__errorArgs = ['Pinterest'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <?php $__errorArgs = ['Pinterest'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>


                                    <div class="form-group row mb-4">

                                        <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3"></label>

                                        <div class="col-sm-12 col-md-7">

                                            <button type="submit"
                                                class="btn btn-primary demo-button"><?php echo e(__('Save')); ?></button>

                                        </div>

                                    </div>


                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="card card-large-icons">
                        <div class="card-icon bg-primary text-white">
                            <i class='fas fa-wrench'></i>
                        </div>
                        <div class="card-body">
                            <h4><?php echo e(__('Maintenance & Frontend Control')); ?></h4>
                            <p><?php echo e(__('Control site maintenance and frontend access. Full maintenance blocks everyone, Frontend toggle blocks only regular users while keeping admin access.')); ?></p>
                            <a href="#maintenace-setting" aria-controls="maintenace-setting" role="button"
                                data-toggle="collapse" class="card-cta" aria-expanded="false"><?php echo e(__('Change Setting')); ?>

                                <i class="fas fa-chevron-right"></i>
                            </a>
                            <div class="collapse mt-3 " id="maintenace-setting">
                                <form method="post" action="<?php echo e(url('maintenance-setting')); ?> "
                                    enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="form-group row mb-4">

                                            <label
                                                class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Maintenance text')); ?></label>

                                            <div class="col-sm-12 col-md-9">

                                                <input type="text" required name="maintenance_text"
                                                    placeholder="<?php echo e(__('text')); ?>"
                                                    value="<?php echo e($setting->maintenance_text); ?>"
                                                    class="form-control <?php $__errorArgs = ['maintenance_text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                                                <?php $__errorArgs = ['maintenance_text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                            </div>

                                        </div>
                                        <div class="form-group row mb-4">

                                            <label
                                                class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Maintenance image')); ?></label>

                                            <div class="col-sm-12 col-md-9">

                                                <input type="file" name="maintenance_bgimg"
                                                    placeholder="<?php echo e(__('Maintenance_image')); ?>"
                                                    class="form-control <?php $__errorArgs = ['maintenance_bgimg'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">


                                                <?php $__errorArgs = ['maintenance_bgimg'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                            </div>

                                        </div>

                                        <div class="col-md-10">
                                            <span><?php echo e(__('Maintenance Mode')); ?></span>
                                        </div>
                                        <div class="custom-switches-stacked col-md-2 mt-2">
                                            <label class="custom-switch pl-0">
                                                <input type="checkbox" name="maintenance_mode"
                                                    class="custom-switch-input" <?php echo e($mode ? 'checked' : ''); ?>>
                                                <span class="custom-switch-indicator"></span>

                                            </label>
                                        </div>
                                    </div>
                                    
                                    <!-- Frontend Toggle Section -->
                                    <div class="row mt-4">
                                        <div class="col-12">
                                            <hr>
                                            <h6 class="text-primary"><i class="fas fa-toggle-on mr-2"></i><?php echo e(__('Frontend Control')); ?></h6>
                                            <small class="text-muted"><?php echo e(__('Control frontend access independently (Admin access remains available)')); ?></small>
                                        </div>
                                    </div>
                                    
                                    <div class="row mt-3">
                                        <div class="col-md-8">
                                            <span><?php echo e(__('Frontend Status')); ?></span>
                                            <br>
                                            <small class="text-muted">
                                                <?php echo e($setting->frontend_maintenance ? __('Frontend is currently DISABLED') : __('Frontend is currently ENABLED')); ?>

                                            </small>
                                        </div>
                                        <div class="custom-switches-stacked col-md-4 mt-2">
                                            <label class="custom-switch pl-0">
                                                <input type="checkbox" name="frontend_maintenance" 
                                                    class="custom-switch-input" <?php echo e($setting->frontend_maintenance ? 'checked' : ''); ?>>
                                                <span class="custom-switch-indicator"></span>
                                                <span class="custom-switch-description"><?php echo e(__('Disable Frontend')); ?></span>
                                            </label>
                                        </div>
                                    </div>
                                    
                                    <div class="row mt-3">
                                        <div class="col-12">
                                            <div class="alert alert-info">
                                                <i class="fas fa-info-circle mr-2"></i>
                                                <strong><?php echo e(__('Note:')); ?></strong> <?php echo e(__('Frontend toggle only affects regular users. Admin users can always access the admin panel.')); ?>

                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group row mb-4 ml-4">
                                        <div class="col-sm-12 text-center">
                                            <button type="submit" class="btn btn-primary mr-2">
                                                <i class="fas fa-save mr-1"></i>
                                                <?php echo e(__('Update Full Maintenance')); ?>

                                            </button>
                                        </div>
                                    </div>
                                </form>
                                
                                <!-- Separate form for Frontend Toggle -->
                                <form method="post" action="<?php echo e(url('frontend-toggle')); ?>" class="mt-3">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="frontend_maintenance" value="<?php echo e($setting->frontend_maintenance ? '1' : '0'); ?>" id="frontend_maintenance_hidden">
                                    <div class="form-group row mb-4 ml-4">
                                        <div class="col-sm-12 text-center">
                                            <button type="button" class="btn <?php echo e($setting->frontend_maintenance ? 'btn-success' : 'btn-warning'); ?>" onclick="toggleFrontend()">
                                                <i class="fas <?php echo e($setting->frontend_maintenance ? 'fa-toggle-on' : 'fa-toggle-off'); ?> mr-1"></i>
                                                <?php echo e($setting->frontend_maintenance ? __('Enable Frontend') : __('Disable Frontend')); ?>

                                            </button>
                                        </div>
                                    </div>

                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="card card-large-icons">
                        <div class="card-icon bg-primary text-white">
                            <i class="fas fa-cog"></i>
                        </div>
                        <div class="card-body">
                            <h4><?php echo e(__('General')); ?></h4>
                            <p><?php echo e(__('General settings such as, site title, site description, logo(PNG Recommended with dimension 143px X 45px) and so on.')); ?>

                            </p>
                            <a href="#general-setting" aria-controls="general-setting" role="button"
                                data-toggle="collapse" class="card-cta" aria-expanded="false"><?php echo e(__('Change Setting')); ?>

                                <i class="fas fa-chevron-right"></i>
                            </a>
                            <div class="collapse mt-3" id="general-setting">
                                <form method="post" action="<?php echo e(url('save-general-setting')); ?>"
                                    enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group row mb-4">
                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('App Name')); ?></label>
                                        <div class="col-sm-12 col-md-9">
                                            <input type="text" required name="app_name"
                                                placeholder="<?php echo e(__('Name')); ?>" value="<?php echo e($setting->app_name); ?>"
                                                class="form-control <?php $__errorArgs = ['app_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <?php $__errorArgs = ['app_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="form-group row mb-4">
                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Email')); ?></label>
                                        <div class="col-sm-12 col-md-9">
                                            <input type="email" name="email" placeholder="<?php echo e(__('Email')); ?>"
                                                value="<?php echo e($setting->email); ?>"
                                                class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="form-group row mb-4">
                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Footer Text')); ?></label>
                                        <div class="col-sm-12 col-md-9">
                                            <input type="text" name="footertext"
                                                placeholder="<?php echo e(__('Text That Appears In Footer')); ?>"
                                                value="<?php echo e($setting->footertext); ?>"
                                                class="form-control <?php $__errorArgs = ['footerText'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <?php $__errorArgs = ['footerText'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="form-group row mb-4">
                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Logo')); ?></label>

                                        <div class="col-sm-12 col-md-9">

                                            <div id="image-preview" class="image-preview setting-logo-preview"
                                                style="background-image: url(<?php echo e(url('images/upload/' . $setting->logo)); ?>)">

                                                <label for="image-upload" id="image-label"> <i
                                                        class="fas fa-plus"></i></label>

                                                <input type="file" name="logo" id="image-upload" />

                                            </div>

                                            <?php $__errorArgs = ['logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                        </div>

                                    </div>


                                    <div class="form-group row mb-4">

                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Favicon')); ?></label>

                                        <div class="col-sm-12 col-md-9">

                                            <div id="image-preview" class="image-preview setting-favicon-preview"
                                                style="background-image: url(<?php echo e(url('images/upload/' . $setting->favicon)); ?>)">

                                                <label for="image-upload" id="image-label"> <i
                                                        class="fas fa-plus"></i></label>

                                                <input type="file" name="favicon" id="image-upload" />

                                            </div>

                                            <?php $__errorArgs = ['favicon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                        </div>

                                    </div>

                                    <div class="form-group row mb-4">

                                        <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3"></label>

                                        <div class="col-sm-12 col-md-7">

                                            <button type="submit"
                                                class="btn btn-primary demo-button"><?php echo e(__('Save')); ?></button>

                                        </div>

                                    </div>

                                </form>

                            </div>

                        </div>

                    </div>

                </div>
                <div class="col-lg-6">

                    <div class="card card-large-icons">

                        <div class="card-icon bg-primary text-white">

                            <i class="fas fa-user-secret"></i>

                        </div>

                        <div class="card-body">

                            <h4><?php echo e(__('Organizer Setting')); ?></h4>

                            <p><?php echo e(__('organizer app settings such as, organizer privacy policy and terms of use.')); ?></p>

                            <a href="#organization-setting" aria-controls="organization-setting" role="button"
                                data-toggle="collapse" class="card-cta" aria-expanded="false"><?php echo e(__('Change Setting')); ?>

                                <i class="fas fa-chevron-right"></i></a>

                            <div class="collapse mt-3" id="organization-setting">

                                <form method="post" class="event-form" action="<?php echo e(url('save-organization-setting')); ?>">

                                    <?php echo csrf_field(); ?>



                                    <div class="form-group">

                                        <label class="col-form-label "><?php echo e(__('Commission Type')); ?></label>

                                        <select required name="org_commission_type" class="form-control select2">

                                            <option value=""><?php echo e(__('Select Commission Type')); ?></option>

                                            <option value="amount"
                                                <?php echo e($setting->org_commission_type == 'amount' ? 'selected' : ''); ?>>

                                                <?php echo e(__('Amount')); ?>


                                            </option>

                                            <option value="percentage"
                                                <?php echo e($setting->org_commission_type == 'percentage' ? 'selected' : ''); ?>>

                                                <?php echo e(__('Percentage')); ?></option>

                                        </select>

                                        <?php $__errorArgs = ['org_commission_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    </div>

                                    <div class="form-group">

                                        <label class="col-form-label"><?php echo e(__('Organizer Commission')); ?></label>

                                        <input type="number" name="org_commission"
                                            placeholder="<?php echo e(__('Organizer Commission')); ?>"
                                            value="<?php echo e($setting->org_commission); ?>"
                                            class="form-control <?php $__errorArgs = ['org_commission'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                                        <?php $__errorArgs = ['org_commission'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    </div>

                                    <div class="form-group">

                                        <label><?php echo e(__('Privacy Policy')); ?></label>

                                        <textarea name="privacy_policy_organizer" Placeholder="<?php echo e(__('Privacy policy')); ?>"
                                            class="textarea_editor <?php $__errorArgs = ['privacy_policy_organizer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                                                                                                <?php echo e($setting->privacy_policy_organizer); ?>


                                                                                            </textarea>

                                        <?php $__errorArgs = ['privacy_policy_organizer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback block"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    </div>

                                    <div class="form-group">

                                        <label><?php echo e(__('Terms of use')); ?></label>

                                        <textarea name="terms_use_organizer" Placeholder="<?php echo e(__('Terms of use')); ?>"
                                            class="textarea_editor <?php $__errorArgs = ['terms_use_organizer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                                                                                                        <?php echo e($setting->terms_use_organizer); ?>


                                                                                                    </textarea>

                                        <?php $__errorArgs = ['terms_use_organizer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback block"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    </div>



                                    <div class="form-group">

                                        <button type="submit"
                                            class="btn btn-primary demo-button"><?php echo e(__('Save')); ?></button>



                                    </div>

                                </form>

                            </div>

                        </div>

                    </div>

                </div>
                <div class="col-lg-6">

                    <div class="card card-large-icons">

                        <div class="card-icon bg-primary text-white">

                            <i class="fas fa-user-check"></i>

                        </div>

                        <div class="card-body">

                            <h4><?php echo e(__('Verification')); ?></h4>

                            <p><?php echo e(__('User Verification settings such as, enable verification and verify user by email or phone.')); ?>


                            </p>

                            <a href="#verification-setting" aria-controls="verification-setting" role="button"
                                data-toggle="collapse" class="card-cta"
                                aria-expanded="false"><?php echo e(__('Change Setting')); ?>

                                <i class="fas fa-chevron-right"></i></a>

                            <div class="collapse mt-3" id="verification-setting">

                                <form method="post" action="<?php echo e(url('save-verification-setting')); ?>">

                                    <?php echo csrf_field(); ?>

                                    <div class="form-group row mb-4">

                                        <label
                                            class="col-form-label text-md-right col-12 col-md-4"><?php echo e(__('Enable User Verification')); ?></label>

                                        <div class="col-sm-12 col-md-8">

                                            <div class="custom-switches-stacked mt-2">

                                                <label class="custom-switch pl-0">

                                                    <input type="checkbox" name="user_verify"
                                                        <?php echo e($setting->user_verify == '1' ? 'checked' : ''); ?>

                                                        value="1" class="custom-switch-input">

                                                    <span class="custom-switch-indicator"></span>

                                                </label>

                                            </div>

                                        </div>

                                    </div>

                                    <div class="form-group row mb-4">

                                        <label
                                            class="col-form-label text-md-right col-12 col-md-4"><?php echo e(__('Verify by Email')); ?></label>

                                        <div class="col-sm-12 col-md-8">

                                            <div class="custom-switches-stacked mt-2">

                                                <label class="custom-switch pl-0">

                                                    <input type="radio" name="verify_by"
                                                        <?php echo e($setting->verify_by == 'email' ? 'checked' : ''); ?>

                                                        value="email" class="custom-switch-input">

                                                    <span class="custom-switch-indicator"></span>

                                                </label>

                                            </div>

                                        </div>

                                    </div>

                                    <div class="form-group row mb-4">

                                        <label
                                            class="col-form-label text-md-right col-12 col-md-4"><?php echo e(__('Verify by Phone')); ?></label>

                                        <div class="col-sm-12 col-md-8">

                                            <div class="custom-switches-stacked mt-2">

                                                <label class="custom-switch pl-0">

                                                    <input type="radio" name="verify_by"
                                                        <?php echo e($setting->verify_by == 'phone' ? 'checked' : ''); ?>

                                                        value="phone" class="custom-switch-input">

                                                    <span class="custom-switch-indicator"></span>

                                                </label>

                                            </div>

                                            <?php $__errorArgs = ['verify_by'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback block"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                        </div>

                                    </div>



                                    <div class="form-group row mb-4">

                                        <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3"></label>

                                        <div class="col-sm-12 col-md-7">

                                            <button type="submit"
                                                class="btn btn-primary demo-button"><?php echo e(__('Save')); ?></button>

                                        </div>

                                    </div>

                                </form>

                            </div>

                        </div>

                    </div>

                </div>
                <div class="col-lg-6">

                    <div class="card card-large-icons">

                        <div class="card-icon bg-primary text-white">

                            <i class="fas fa-hand-holding-usd"></i>

                        </div>

                        <div class="card-body">

                            <h4><?php echo e(__('Payment Setting')); ?></h4>

                            <p><?php echo e(__('Payment settings include different payment gateway and which will display on app.')); ?>


                            </p>

                            <div id="errorMessage" class="text-danger d-none mb-3">Please select at least one payment type.</div>

                            <a href="#payment-setting" aria-controls="payment-setting" role="button"
                                data-toggle="collapse" class="card-cta"
                                aria-expanded="false"><?php echo e(__('Change Setting')); ?>

                                <i class="fas fa-chevron-right"></i></a>

                            <div class="collapse mt-3" id="payment-setting">

                                <form id="paymentForm" method="post" action="<?php echo e(url('save-payment-setting')); ?>">

                                    <?php echo csrf_field(); ?>
                                    <div class="form-group row mb-4">

                                        <label class="col-form-label text-md-right col-12 col-md-3" data-toggle="tooltip"
                                            data-placement="top"
                                            title="Setting it off will hide the Wallet feature completely from the Customer's view. Including existing balance if any."><?php echo e(__('Wallet System')); ?></label>

                                        <div class="col-sm-12 col-md-9">

                                            <div class="custom-switches-stacked mt-2">

                                                <label class="custom-switch pl-0">

                                                    <input type="checkbox" name="wallet"
                                                        <?php echo e($payment->wallet == '1' ? 'checked' : ''); ?> value="1"
                                                        class="custom-switch-input">

                                                    <span class="custom-switch-indicator"></span>

                                                </label>

                                            </div>

                                        </div>

                                    </div>

                                    <div class="form-group row mb-4">

                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3"><?php echo e(__('Cash on Delivery')); ?></label>

                                        <div class="col-sm-12 col-md-9">

                                            <div class="custom-switches-stacked mt-2">

                                                <label class="custom-switch pl-0">

                                                    <input type="checkbox" name="cod"
                                                        <?php echo e($payment->cod == '1' ? 'checked' : ''); ?> value="1"
                                                        class="custom-switch-input paymentCheckbox">

                                                    <span class="custom-switch-indicator"></span>

                                                </label>

                                            </div>

                                        </div>

                                    </div>


                                    <div class="form-group row mb-4">

                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3"><?php echo e(__('Stripe')); ?></label>

                                        <div class="col-sm-12 col-md-9">

                                            <div class="custom-switches-stacked mt-2">

                                                <label class="custom-switch pl-0">

                                                    <input type="checkbox" name="stripe"
                                                        <?php echo e($payment->stripe == '1' ? 'checked' : ''); ?> value="1"
                                                        class="custom-switch-input paymentCheckbox">

                                                    <span class="custom-switch-indicator"></span>

                                                </label>

                                            </div>

                                        </div>

                                    </div>

                                    <div class="form-group row mb-4">

                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3"><?php echo e(__('Paypal')); ?></label>

                                        <div class="col-sm-12 col-md-9">

                                            <div class="custom-switches-stacked mt-2">

                                                <label class="custom-switch pl-0">

                                                    <input type="checkbox" name="paypal"
                                                        <?php echo e($payment->paypal == '1' ? 'checked' : ''); ?> value="1"
                                                        class="custom-switch-input paymentCheckbox">

                                                    <span class="custom-switch-indicator"></span>

                                                </label>

                                            </div>

                                        </div>

                                    </div>

                                    <div class="form-group row mb-4">

                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3"><?php echo e(__('Flutterwave')); ?></label>

                                        <div class="col-sm-12 col-md-9">

                                            <div class="custom-switches-stacked mt-2">

                                                <label class="custom-switch pl-0">

                                                    <input type="checkbox" name="flutterwave"
                                                        <?php echo e($payment->flutterwave == '1' ? 'checked' : ''); ?>

                                                        value="1" class="custom-switch-input paymentCheckbox">

                                                    <span class="custom-switch-indicator"></span>

                                                </label>

                                            </div>

                                        </div>

                                    </div>

                                    <div class="form-group row mb-4">

                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3"><?php echo e(__('Razorpay')); ?></label>

                                        <div class="col-sm-12 col-md-9">

                                            <div class="custom-switches-stacked mt-2">

                                                <label class="custom-switch pl-0">

                                                    <input type="checkbox" name="razor"
                                                        <?php echo e($payment->razor == '1' ? 'checked' : ''); ?> value="1"
                                                        class="custom-switch-input paymentCheckbox">

                                                    <span class="custom-switch-indicator"></span>

                                                </label>

                                            </div>

                                        </div>

                                    </div>

                                    <div class="form-group row mb-4">

                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Stripe secret key')); ?></label>

                                        <div class="col-sm-12 col-md-9">

                                            <input type="text" name="stripeSecretKey"
                                                placeholder="<?php echo e(__('Stripe secret key')); ?>"
                                                value="<?php echo e($payment->stripeSecretKey); ?>"
                                                class="form-control <?php $__errorArgs = ['stripeSecretKey'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">


                                            <?php $__errorArgs = ['stripeSecretKey'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                    </div>

                                    <div class="form-group row mb-4">

                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Stripe public key')); ?></label>

                                        <div class="col-sm-12 col-md-9">

                                            <input type="text" name="stripePublicKey"
                                                placeholder="<?php echo e(__('Stripe public key')); ?>"
                                                value="<?php echo e($payment->stripePublicKey); ?>"
                                                class="form-control <?php $__errorArgs = ['stripePublicKey'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                                            <?php $__errorArgs = ['stripePublicKey'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            <a href="https://stripe.com/docs/keys#obtain-api-keys" target="_blank"
                                                class="btn btn-primary demo-button mt-2"><?php echo e(__('Help')); ?>

                                            </a>
                                        </div>

                                    </div>

                                    <div class="form-group row mb-4">

                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Paypal Client ID')); ?></label>

                                        <div class="col-sm-12 col-md-9">

                                            <input type="text" name="paypalClientId"
                                                placeholder="<?php echo e(__('Paypal Client ID')); ?>"
                                                value="<?php echo e($payment->paypalClientId); ?>"
                                                class="form-control <?php $__errorArgs = ['paypalClientId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                                            <?php $__errorArgs = ['paypalClientId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                        </div>

                                    </div>

                                    <div class="form-group row mb-4">

                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Paypal Secret key')); ?></label>

                                        <div class="col-sm-12 col-md-9">

                                            <input type="text" name="paypalSecret"
                                                placeholder="<?php echo e(__('Paypal Secret key')); ?>"
                                                value="<?php echo e($payment->paypalSecret); ?>"
                                                class="form-control <?php $__errorArgs = ['paypalSecret'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                                            <?php $__errorArgs = ['paypalSecret'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            <a href="https://www.appinvoice.com/en/s/documentation/how-to-get-paypal-client-id-and-secret-key-22"
                                                target="_blank"
                                                class="btn btn-primary demo-button mt-2"><?php echo e(__('Help')); ?>

                                            </a>
                                        </div>

                                    </div>

                                    <div class="form-group row mb-4">

                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Razorpay Publish key')); ?></label>

                                        <div class="col-sm-12 col-md-9">

                                            <input type="text" name="razorPublishKey"
                                                placeholder="<?php echo e(__('Razorpay Publish key')); ?>"
                                                value="<?php echo e($payment->razorPublishKey); ?>"
                                                class="form-control <?php $__errorArgs = ['razorPublishKey'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                                            <?php $__errorArgs = ['razorPublishKey'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                        </div>

                                    </div>

                                    <div class="form-group row mb-4">

                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Razorpay Secret key')); ?></label>

                                        <div class="col-sm-12 col-md-9">

                                            <input type="text" name="razorSecretKey"
                                                placeholder="<?php echo e(__('Razorpay Secret key')); ?>"
                                                value="<?php echo e($payment->razorSecretKey); ?>"
                                                class="form-control <?php $__errorArgs = ['razorSecretKey'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                                            <?php $__errorArgs = ['razorSecretKey'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            <a href="https://razorpay.com/docs/payments/dashboard/settings/api-keys/"
                                                target="_blank"
                                                class="btn btn-primary demo-button mt-2"><?php echo e(__('Help')); ?>

                                            </a>
                                        </div>

                                    </div>

                                    <div class="form-group row mb-4">

                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Flutterwave public key')); ?></label>

                                        <div class="col-sm-12 col-md-9">

                                            <input type="text" name="ravePublicKey"
                                                placeholder="<?php echo e(__('Flutterwave public key')); ?>"
                                                value="<?php echo e($payment->ravePublicKey); ?>"
                                                class="form-control <?php $__errorArgs = ['ravePublicKey'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                                            <?php $__errorArgs = ['ravePublicKey'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                        </div>

                                    </div>
                                    <div class="form-group row mb-4">

                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Flutterwave secret key')); ?></label>

                                        <div class="col-sm-12 col-md-9">

                                            <input type="text" name="raveSecretKey"
                                                placeholder="<?php echo e(__('Flutterwave secret key')); ?>"
                                                value="<?php echo e($payment->raveSecretKey); ?>"
                                                class="form-control <?php $__errorArgs = ['raveSecretKey'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <?php $__errorArgs = ['raveSecretKey'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                        </div>

                                    </div>
                                    <div class="form-group row mb-4">

                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Flutterwave Debugg mode')); ?></label>

                                        <div class="col-sm-12 col-md-9">

                                            <div class=" mt-2">
                                                <select name="flutterDebugMode" id=""
                                                    class=" dropdown form-control">
                                                    <option value="1"><?php echo e(__('Yes')); ?></option>
                                                    <option value="0"><?php echo e(__('No')); ?></option>
                                                </select>
                                            </div>
                                            <?php $__errorArgs = ['flutterDebugMode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            <a href="https://developer.flutterwave.com/docs/quickstart" target="_blank"
                                                class="btn btn-primary demo-button mt-2"><?php echo e(__('Help')); ?>

                                            </a>
                                        </div>

                                    </div>

                                    <div class="form-group row mb-4">

                                        <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3"></label>

                                        <div class="col-sm-12 col-md-7">

                                            <button type="submit"
                                                class="btn btn-primary demo-button"><?php echo e(__('Save')); ?></button>

                                        </div>

                                    </div>

                                </form>

                            </div>

                        </div>

                    </div>

                </div>
                <div class="col-lg-6">

                    <div class="card card-large-icons">

                        <div class="card-icon bg-primary text-white">

                            <i class="fas fa-envelope"></i>

                        </div>

                        <div class="card-body">

                            <h4><?php echo e(__('Mail Notification')); ?></h4>

                            <p><?php echo e(__('Email SMTP configuration settings and email notifications related to email.')); ?>


                            </p>

                            <a href="#mail-setting" aria-controls="mail-setting" role="button" data-toggle="collapse"
                                class="card-cta" aria-expanded="false"><?php echo e(__('Change Setting')); ?> <i
                                    class="fas fa-chevron-right"></i></a>

                            <div class="collapse mt-3" id="mail-setting">

                                <form method="post" action="<?php echo e(url('save-mail-setting')); ?>">

                                    <?php echo csrf_field(); ?>

                                    <div class="form-group row mb-4">

                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Enable Notification')); ?></label>

                                        <div class="col-sm-12 col-md-9">

                                            <div class="custom-switches-stacked mt-2">

                                                <label class="custom-switch pl-0">

                                                    <input type="checkbox" name="mail_notification"
                                                        <?php echo e($setting->mail_notification == '1' ? 'checked' : ''); ?>

                                                        value="1" class="custom-switch-input">

                                                    <span class="custom-switch-indicator"></span>

                                                </label>

                                            </div>

                                        </div>

                                    </div>

                                    <div class="form-group row mb-4">

                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Mail Host')); ?></label>

                                        <div class="col-sm-12 col-md-9">

                                            <input type="text" name="mail_host" placeholder="<?php echo e(__('Mail Host')); ?>"
                                                value="<?php echo e($setting->mail_host); ?>"
                                                class="form-control <?php $__errorArgs = ['mail_host'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                                            <?php $__errorArgs = ['mail_host'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                        </div>

                                    </div>

                                    <div class="form-group row mb-4">

                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Mail Port')); ?></label>

                                        <div class="col-sm-12 col-md-9">

                                            <input type="number" name="mail_port" placeholder="<?php echo e(__('Mail Port')); ?>"
                                                value="<?php echo e($setting->mail_port); ?>"
                                                class="form-control <?php $__errorArgs = ['mail_port'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                                            <?php $__errorArgs = ['mail_port'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                        </div>

                                    </div>

                                    <div class="form-group row mb-4">
                                        <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Mail Encryption')); ?></label>
                                        <div class="col-sm-12 col-md-9">
                                            <select required name="mail_encryption" class="form-control select2">
                                                <option value="" disabled><?php echo e(__('Mail Encryption/Authentication')); ?></option>
                                                <option value="ssl"
                                                    <?php echo e($setting->mail_encryption == 'ssl' ? 'selected' : ''); ?>>
                                                    <?php echo e(__('ssl')); ?>

                                                </option>
                                                <option value="tls"
                                                    <?php echo e($setting->mail_encryption == 'tls' ? 'selected' : ''); ?>>
                                                    <?php echo e(__('tls')); ?></option>
                                            </select>
                                            <?php $__errorArgs = ['mail_encryption'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>

                                    <div class="form-group row mb-4">
                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Mail Mailer')); ?></label>
                                        <div class="col-sm-12 col-md-9">
                                            <select required name="mail_mailer" class="form-control select2">
                                                <option value="smtp"
                                                    <?php echo e($setting->mail_mailer == 'smtp' || !$setting->mail_mailer ? 'selected' : ''); ?>>
                                                    <?php echo e(__('smtp')); ?>

                                                </option>
                                                <option value="mailgun"
                                                    <?php echo e($setting->mail_encryption == 'mailgun' ? 'selected' : ''); ?>>
                                                    <?php echo e(__('mailgun')); ?></option>
                                            </select>
                                            <?php $__errorArgs = ['mail_mailer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>

                                    <div class="form-group row mb-4">

                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Mail Username')); ?></label>

                                        <div class="col-sm-12 col-md-9">

                                            <input type="text" name="mail_username"
                                                placeholder="<?php echo e(__('Mail Username')); ?>"
                                                value="<?php echo e($setting->mail_username); ?>"
                                                class="form-control <?php $__errorArgs = ['mail_username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                                            <?php $__errorArgs = ['mail_username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                        </div>

                                    </div>

                                    <div class="form-group row mb-4">

                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Mail Password')); ?></label>

                                        <div class="col-sm-12 col-md-9">

                                            <input type="password" name="mail_password"
                                                placeholder="<?php echo e(__('Mail Password')); ?>"
                                                value="<?php echo e($setting->mail_password); ?>"
                                                class="form-control <?php $__errorArgs = ['mail_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                                            <?php $__errorArgs = ['mail_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                        </div>

                                    </div>

                                    <div class="form-group row mb-4">

                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Mail Sender Email')); ?></label>

                                        <div class="col-sm-12 col-md-9">

                                            <input type="email" name="sender_email"
                                                placeholder="<?php echo e(__('Mail Sender Email')); ?>"
                                                value="<?php echo e($setting->sender_email); ?>"
                                                class="form-control <?php $__errorArgs = ['sender_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                                            <?php $__errorArgs = ['sender_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            <a href="https://sendgrid.com/blog/what-is-an-smtp-server/" target="_blank"
                                                class="btn btn-primary demo-button mt-3"><?php echo e(__('Help')); ?>

                                            </a>

                                        </div>

                                    </div>

                                    <div class="form-group row mb-4">

                                        <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3"></label>

                                        <div class="col-sm-12 col-md-7">

                                            <button type="submit"
                                                class="btn btn-primary demo-button"><?php echo e(__('Save')); ?></button>

                                        </div>

                                    </div>
                                    <div class="form-group row mb-4">

                                        <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3"></label>

                                        <div class="col-sm-12 col-md-7">


                                            <div class="div text-left mx-1">
                                                <input type="button" value="<?php echo e(__('Test Mail')); ?>" data-toggle="modal"
                                                    data-target="#exampleModalCenter" class=" btn btn-primary ">
                                            </div>

                                        </div>

                                    </div>

                                </form>

                            </div>

                        </div>

                    </div>

                </div>
                <div class="col-lg-6">

                    <div class="card card-large-icons">

                        <div class="card-icon bg-primary text-white">

                            <i class="fas fa-bell"></i>

                        </div>

                        <div class="card-body">

                            <h4><?php echo e(__('Push Notification')); ?></h4>

                            <p><?php echo e(__('OneSignal configuration settings and app push notifications setting.')); ?></p>

                            <a href="#push-notification-setting" aria-controls="push-notification-setting" role="button"
                                data-toggle="collapse" class="card-cta"
                                aria-expanded="false"><?php echo e(__('Change Setting')); ?> <i
                                    class="fas fa-chevron-right"></i></a>

                            <div class="collapse mt-3" id="push-notification-setting">

                                <form method="post" action="<?php echo e(url('save-pushNotification-setting')); ?>">

                                    <?php echo csrf_field(); ?>

                                    <div class="form-group row mb-4">

                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Enable Notification')); ?></label>

                                        <div class="col-sm-12 col-md-9">

                                            <div class="custom-switches-stacked mt-2">

                                                <label class="custom-switch pl-0">

                                                    <input type="checkbox" name="push_notification"
                                                        <?php echo e($setting->push_notification == '1' ? 'checked' : ''); ?>

                                                        value="1" class="custom-switch-input">

                                                    <span class="custom-switch-indicator"></span>

                                                </label>

                                            </div>

                                        </div>

                                    </div>

                                    <p><?php echo e(__('OneSignal configuration for user app:')); ?></p>

                                    <div class="form-group row mb-4">

                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Onesignal App Id')); ?></label>

                                        <div class="col-sm-12 col-md-9">

                                            <input type="text" name="onesignal_app_id"
                                                placeholder="<?php echo e(__('OneSignal App Id')); ?>"
                                                value="<?php echo e($setting->onesignal_app_id); ?>"
                                                class="form-control <?php $__errorArgs = ['onesignal_app_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                                            <?php $__errorArgs = ['onesignal_app_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                        </div>

                                    </div>

                                    <div class="form-group row mb-4">

                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Onesignal Project Number')); ?></label>

                                        <div class="col-sm-12 col-md-9">

                                            <input type="text" name="onesignal_project_number"
                                                placeholder="<?php echo e(__('Onesignal Project Number')); ?>"
                                                value="<?php echo e($setting->onesignal_project_number); ?>"
                                                class="form-control <?php $__errorArgs = ['onesignal_project_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                                            <?php $__errorArgs = ['onesignal_project_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                        </div>

                                    </div>

                                    <div class="form-group row mb-4">

                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Onesignal Api key')); ?></label>

                                        <div class="col-sm-12 col-md-9">

                                            <input type="text" name="onesignal_api_key"
                                                placeholder="<?php echo e(__('Onesignal Api key')); ?>"
                                                value="<?php echo e($setting->onesignal_api_key); ?>"
                                                class="form-control <?php $__errorArgs = ['onesignal_api_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                                            <?php $__errorArgs = ['onesignal_api_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                        </div>

                                    </div>

                                    <div class="form-group row mb-4">

                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Onesignal Auth Key')); ?></label>

                                        <div class="col-sm-12 col-md-9">

                                            <input type="text" name="onesignal_auth_key"
                                                placeholder="<?php echo e(__('Onesignal Auth Key')); ?>"
                                                value="<?php echo e($setting->onesignal_auth_key); ?>"
                                                class="form-control <?php $__errorArgs = ['onesignal_auth_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                                            <?php $__errorArgs = ['onesignal_auth_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                        </div>

                                    </div>

                                    <p><?php echo e(__('OneSignal configuration for organizer app:')); ?></p>

                                    <div class="form-group row mb-4">

                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Onesignal App Id')); ?></label>

                                        <div class="col-sm-12 col-md-9">

                                            <input type="text" name="or_onesignal_app_id"
                                                placeholder="<?php echo e(__('OneSignal App Id')); ?>"
                                                value="<?php echo e($setting->or_onesignal_app_id); ?>"
                                                class="form-control <?php $__errorArgs = ['or_onesignal_app_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                                            <?php $__errorArgs = ['or_onesignal_app_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                        </div>

                                    </div>

                                    <div class="form-group row mb-4">

                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Onesignal Project Number')); ?></label>

                                        <div class="col-sm-12 col-md-9">

                                            <input type="text" name="or_onesignal_project_number"
                                                placeholder="<?php echo e(__('Onesignal Project Number')); ?>"
                                                value="<?php echo e($setting->or_onesignal_project_number); ?>"
                                                class="form-control <?php $__errorArgs = ['or_onesignal_project_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                                            <?php $__errorArgs = ['or_onesignal_project_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                        </div>

                                    </div>

                                    <div class="form-group row mb-4">

                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Onesignal Api key')); ?></label>

                                        <div class="col-sm-12 col-md-9">

                                            <input type="text" name="or_onesignal_api_key"
                                                placeholder="<?php echo e(__('Onesignal Api key')); ?>"
                                                value="<?php echo e($setting->or_onesignal_api_key); ?>"
                                                class="form-control <?php $__errorArgs = ['or_onesignal_api_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                                            <?php $__errorArgs = ['or_onesignal_api_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                        </div>

                                    </div>



                                    <div class="form-group row mb-4">

                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Onesignal Auth Key')); ?></label>

                                        <div class="col-sm-12 col-md-9">

                                            <input type="text" name="or_onesignal_auth_key"
                                                placeholder="<?php echo e(__('Onesignal Auth Key')); ?>"
                                                value="<?php echo e($setting->or_onesignal_auth_key); ?>"
                                                class="form-control <?php $__errorArgs = ['or_onesignal_auth_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                                            <?php $__errorArgs = ['or_onesignal_auth_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                            <a href="https://documentation.onesignal.com/docs/accounts-and-keys"
                                                target="_blank"
                                                class="btn btn-primary demo-button mt-2"><?php echo e(__('Help')); ?>

                                            </a>

                                        </div>

                                    </div>



                                    <div class="form-group row mb-4">

                                        <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3"></label>

                                        <div class="col-sm-12 col-md-7">

                                            <button type="submit"
                                                class="btn btn-primary demo-button"><?php echo e(__('Save')); ?></button>

                                        </div>

                                    </div>

                                </form>

                            </div>

                        </div>

                    </div>

                </div>
                <div class="col-lg-6">

                    <div class="card card-large-icons">

                        <div class="card-icon bg-primary text-white">

                            <i class="fas fa-sms"></i>

                        </div>

                        <div class="card-body">

                            <h4><?php echo e(__('SMS Notification')); ?></h4>

                            <p><?php echo e(__('SMS configuration settings of twillio SMS gateway and vonage.')); ?></p>

                            <a href="#push-sms-setting" aria-controls="push-sms-setting" role="button"
                                data-toggle="collapse" class="card-cta"
                                aria-expanded="false"><?php echo e(__('Change Setting')); ?> <i
                                    class="fas fa-chevron-right"></i></a>

                            <div class="collapse mt-3" id="push-sms-setting">

                                <form method="post" action="<?php echo e(url('save-sms-setting')); ?>">

                                    <?php echo csrf_field(); ?>

                                    <div class="form-group row mb-4">

                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Enable SMS Notification')); ?></label>

                                        <div class="col-sm-12 col-md-9">

                                            <div class="custom-switches-stacked mt-2">

                                                <label class="custom-switch pl-0">

                                                    <input type="checkbox" name="sms_notification"
                                                        <?php echo e($setting->sms_notification == '1' ? 'checked' : ''); ?>

                                                        value="1" class="custom-switch-input">

                                                    <span class="custom-switch-indicator"></span>

                                                </label>

                                            </div>

                                        </div>

                                    </div>

                                    <div class="form-group row mb-4">
                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Enable Twillio')); ?></label>
                                        <div class="col-sm-12 col-md-9">
                                            <div class="custom-switches-stacked mt-2">
                                                <label class="custom-switch pl-0">
                                                    <input type="radio" name="enable_sms"
                                                        <?php echo e($setting->enable_twillio == 1 ? 'checked' : ''); ?>

                                                        value="twillio" class="custom-switch-input">
                                                    <span class="custom-switch-indicator"></span>
                                                </label>
                                            </div>
                                            <?php $__errorArgs = ['enable_twillio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback block"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="form-group row mb-4">
                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Enable Vonage')); ?></label>
                                        <div class="col-sm-12 col-md-9">
                                            <div class="custom-switches-stacked mt-2">
                                                <label class="custom-switch pl-0">
                                                    <input type="radio" name="enable_sms"
                                                        <?php echo e($setting->enable_vonage == 1 ? 'checked' : ''); ?>

                                                        value="vonage" class="custom-switch-input">
                                                    <span class="custom-switch-indicator"></span>
                                                </label>
                                            </div>
                                            <?php $__errorArgs = ['enable_vonage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback block"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                        </div>

                                    </div>

                                    <div class="form-group row mb-4">

                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Twilio Account ID')); ?></label>

                                        <div class="col-sm-12 col-md-9">

                                            <input type="text" name="twilio_account_id"
                                                placeholder="<?php echo e(__('Twilio Account ID')); ?>"
                                                value="<?php echo e($setting->twilio_account_id); ?>"
                                                class="form-control <?php $__errorArgs = ['twilio_account_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                                            <?php $__errorArgs = ['twilio_account_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                        </div>

                                    </div>

                                    <div class="form-group row mb-4">

                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Twilio auth token')); ?></label>

                                        <div class="col-sm-12 col-md-9">

                                            <input type="text" name="twilio_auth_token"
                                                placeholder="<?php echo e(__('Twilio auth token')); ?>"
                                                value="<?php echo e($setting->twilio_auth_token); ?>"
                                                class="form-control <?php $__errorArgs = ['twilio_auth_token'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                                            <?php $__errorArgs = ['twilio_auth_token'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                        </div>

                                    </div>

                                    <div class="form-group row mb-4">

                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Twilio phone number')); ?></label>

                                        <div class="col-sm-12 col-md-9">

                                            <input type="text" name="twilio_phone_number"
                                                placeholder="<?php echo e(__('Twilio phone number')); ?>"
                                                value="<?php echo e($setting->twilio_phone_number); ?>"
                                                class="form-control <?php $__errorArgs = ['twilio_phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                                            <?php $__errorArgs = ['twilio_phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            <a href="https://www.twilio.com/docs/glossary/what-is-an-api-key"
                                                target="_blank"
                                                class="btn btn-primary demo-button mt-2"><?php echo e(__('Help')); ?>

                                            </a>
                                        </div>

                                    </div>

                                    <div class="form-group row mb-4">

                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Vonage API key')); ?></label>

                                        <div class="col-sm-12 col-md-9">

                                            <input type="text" name="vonege_api_key"
                                                placeholder="<?php echo e(__('Vonage API key')); ?>"
                                                value="<?php echo e($setting->vonege_api_key); ?>"
                                                class="form-control <?php $__errorArgs = ['vonege_api_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                                            <?php $__errorArgs = ['vonege_api_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                        </div>

                                    </div>

                                    <div class="form-group row mb-4">

                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Vonage Account Secret')); ?></label>

                                        <div class="col-sm-12 col-md-9">

                                            <input type="text" name="vonage_account_secret"
                                                placeholder="<?php echo e(__('Vonage Account Secret')); ?>"
                                                value="<?php echo e($setting->vonage_account_secret); ?>"
                                                class="form-control <?php $__errorArgs = ['vonage_account_secret'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                                            <?php $__errorArgs = ['vonage_account_secret'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                        </div>

                                    </div>

                                    <div class="form-group row mb-4">

                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Vonage Sender Number')); ?></label>

                                        <div class="col-sm-12 col-md-9">

                                            <input type="text" name="vonage_sender_number"
                                                placeholder="<?php echo e(__('Vonage Sender Number')); ?>"
                                                value="<?php echo e($setting->vonage_sender_number); ?>"
                                                class="form-control <?php $__errorArgs = ['vonage_sender_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                                            <?php $__errorArgs = ['vonage_sender_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            <a href="https://www.twilio.com/docs/glossary/what-is-an-api-key"
                                                target="_blank"
                                                class="btn btn-primary demo-button mt-2"><?php echo e(__('Help')); ?>

                                            </a>
                                        </div>

                                    </div>
                                    <div class="form-group row mb-4">

                                        <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3"></label>

                                        <div class="col-sm-12 col-md-7">

                                            <button type="submit"
                                                class="btn btn-primary demo-button"><?php echo e(__('Save')); ?></button>

                                        </div>

                                    </div>

                                </form>

                            </div>

                        </div>

                    </div>

                </div>
                <div class="col-lg-6">

                    <div class="card card-large-icons">

                        <div class="card-icon bg-primary text-white">

                            <i class="fas fa-tools"></i>

                        </div>

                        <div class="card-body">

                            <h4><?php echo e(__('Additional Setting')); ?></h4>

                            <p><?php echo e(__('General setting such as currency, map key, default map coordinates and so on.')); ?>


                            </p>

                            <a href="#additional-setting" aria-controls="additional-setting" role="button"
                                data-toggle="collapse" class="card-cta"
                                aria-expanded="false"><?php echo e(__('Change Setting')); ?> <i
                                    class="fas fa-chevron-right"></i></a>

                            <div class="collapse mt-3" id="additional-setting">

                                <form method="post" action="<?php echo e(url('additional-setting')); ?>">

                                    <?php echo csrf_field(); ?>

                                    <div class="form-group row mb-4">

                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Currency')); ?></label>

                                        <div class="col-sm-12 col-md-9">

                                            <select required name="currency" class="form-control select2">

                                                <option value=""><?php echo e(__('Select default currency')); ?></option>

                                                <?php $__currentLoopData = $currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item->id); ?>"
                                                        <?php echo e($setting->currency_id == $item->id ? 'Selected' : ''); ?>>
                                                        <?php echo e($item->currency . ' ( ' . $item->symbol . '- ' . $item->code . ')'); ?>(<?php echo e($item->country); ?>)
                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </select>

                                            <?php $__errorArgs = ['currency'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                        </div>

                                    </div>

                                    <div class="form-group row mb-4">

                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('TimeZone')); ?></label>

                                        <div class="col-sm-12 col-md-9">

                                            <select required name="timezone" class="form-control select2">

                                                <option value=""><?php echo e(__('Select default Timezone')); ?></option>

                                                <?php $__currentLoopData = $timezone; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item->TimeZone); ?>"
                                                        <?php echo e($setting->timezone == $item->TimeZone ? 'Selected' : ''); ?>>

                                                        <?php echo e($item->TimeZone); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </select>

                                            <?php $__errorArgs = ['timezone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                        </div>

                                    </div>

                                    <div class="form-group row mb-4">

                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Language')); ?></label>

                                        <div class="col-sm-12 col-md-9">

                                            <select required name="language" class="form-control select2">

                                                <option value=""><?php echo e(__('Select default Language')); ?></option>

                                                <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($language->name); ?>"
                                                        <?php echo e($language->name == $setting->language ? 'Selected' : ''); ?>>

                                                        <?php echo e($language->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </select>

                                            <?php $__errorArgs = ['language'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                        </div>

                                    </div>

                                    <div class="form-group row mb-4">

                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('App Version')); ?></label>

                                        <div class="col-sm-12 col-md-9">

                                            <input type="text" required name="app_version"
                                                placeholder="<?php echo e(__('App Version')); ?>"
                                                value="<?php echo e($setting->app_version); ?>"
                                                class="form-control <?php $__errorArgs = ['app_version'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                                            <?php $__errorArgs = ['app_version'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                        </div>

                                    </div>

                                    <div class="form-group row mb-4">

                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('CopyRight content')); ?></label>

                                        <div class="col-sm-12 col-md-9">

                                            <input type="text" required name="footer_copyright"
                                                placeholder="<?php echo e(__('Footer CopyRight Content')); ?>"
                                                value="<?php echo e($setting->footer_copyright); ?>"
                                                class="form-control <?php $__errorArgs = ['footer_copyright'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                                            <?php $__errorArgs = ['footer_copyright'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                        </div>

                                    </div>

                                    <div class="form-group row mb-4">

                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Map key')); ?></label>

                                        <div class="col-sm-12 col-md-9">

                                            <input type="text" name="map_key" placeholder="<?php echo e(__('Map key')); ?>"
                                                value="<?php echo e($setting->map_key); ?>"
                                                class="form-control <?php $__errorArgs = ['map_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                                            <?php $__errorArgs = ['map_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            <a href="https://docs.saasmonks.in/external-configuration-documentation-links/google-map-keys"
                                                target="_blank"
                                                class="btn btn-primary demo-button mt-2"><?php echo e(__('Help')); ?>

                                            </a>
                                        </div>

                                    </div>

                                    <div class="form-group row mb-4">

                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Default Latitude')); ?></label>

                                        <div class="col-sm-12 col-md-9">

                                            <input type="text" required name="default_lat"
                                                placeholder="<?php echo e(__('Default Latitude')); ?>"
                                                value="<?php echo e($setting->default_lat); ?>"
                                                class="form-control <?php $__errorArgs = ['default_lat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                                            <?php $__errorArgs = ['default_lat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                        </div>

                                    </div>

                                    <div class="form-group row mb-4">

                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Default Longitude')); ?></label>

                                        <div class="col-sm-12 col-md-9">

                                            <input type="text" required name="default_long"
                                                placeholder="<?php echo e(__('Default Longitude')); ?>"
                                                value="<?php echo e($setting->default_long); ?>"
                                                class="form-control <?php $__errorArgs = ['default_long'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                                            <?php $__errorArgs = ['default_long'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                        </div>

                                    </div>

                                    <div class="form-group row mb-4">

                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Primary Color')); ?></label>

                                        <div class="col-sm-12 col-md-9">

                                            <div class="input-group colorpickerinput">

                                                <input type="text" name="primary_color"
                                                    value="<?php echo e($setting->primary_color); ?>"
                                                    placeholder="<?php echo e(__('Choose color')); ?>"
                                                    class="form-control  <?php $__errorArgs = ['primary_color'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                                                <div class="input-group-append">

                                                    <div class="input-group-text color-input">

                                                    </div>

                                                </div>

                                            </div>

                                            <?php $__errorArgs = ['primary_color'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                        </div>

                                    </div>
                                    <div class="form-group row mb-4">
                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Show App Link Banner')); ?></label>
                                        <div class="col-sm-12 col-md-9">
                                            <div class="custom-switches-stacked mt-2">
                                                <label class="custom-switch pl-0">
                                                    <input type="checkbox" name="show_link_banner"
                                                        <?php echo e($setting->show_link_banner == 1 ? 'checked' : ''); ?>

                                                        value="1" class="custom-switch-input">
                                                    <span class="custom-switch-indicator"></span>
                                                </label>
                                            </div>
                                            <?php $__errorArgs = ['show_link_banner'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback block"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="form-group row mb-4">
                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('App GooglePlay Link')); ?></label>
                                        <div class="col-sm-12 col-md-9">
                                            <input type="url" name="googleplay_link"
                                                placeholder="<?php echo e(__('Customer App GooglePlay Link')); ?>"
                                                value="<?php echo e($setting->googleplay_link); ?>"
                                                class="form-control <?php $__errorArgs = ['googleplay_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <?php $__errorArgs = ['googleplay_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="form-group row mb-4">
                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('App AppStore Link')); ?></label>
                                        <div class="col-sm-12 col-md-9">
                                            <input type="url" name="appstore_link"
                                                placeholder="<?php echo e(__('Customer App AppStore Link')); ?>"
                                                value="<?php echo e($setting->appstore_link); ?>"
                                                class="form-control <?php $__errorArgs = ['appstore_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <?php $__errorArgs = ['appstore_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="form-group row mb-4">

                                        <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3"></label>

                                        <div class="col-sm-12 col-md-7">

                                            <button type="submit"
                                                class="btn btn-primary demo-button"><?php echo e(__('Save')); ?></button>

                                        </div>

                                    </div>

                                </form>

                            </div>

                        </div>

                    </div>

                </div>
                <div class="col-lg-6">

                    <div class="card card-large-icons">

                        <div class="card-icon bg-primary text-white">

                            <i class="fas fa-solid fa-users"></i>

                        </div>

                        <div class="card-body">

                            <h4><?php echo e(__('Appuser Privacy Policy')); ?></h4>

                            <p><?php echo e(__('Describe appuser privacy policy')); ?>


                            </p>

                            <a href="#AppuserPrivacyPolicy" aria-controls="additional-setting" role="button"
                                data-toggle="collapse" class="card-cta"
                                aria-expanded="false"><?php echo e(__('Change Setting')); ?> <i
                                    class="fas fa-chevron-right"></i></a>

                            <div class="collapse mt-3" id="AppuserPrivacyPolicy">

                                <form method="post" action="<?php echo e(url('appuser-privacy-policy')); ?>">

                                    <?php echo csrf_field(); ?>

                                    <div class="form-group ">

                                        <label><?php echo e(__('Appuser Privacy Policy')); ?></label>

                                        <textarea name="appuser_privacy_policy" Placeholder="<?php echo e(__('Privacy policy')); ?>"
                                            class="textarea_editor <?php $__errorArgs = ['appuser_privacy_policy'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                                            <?php echo e($setting->appuser_privacy_policy); ?>


                                        </textarea>

                                        <?php $__errorArgs = ['appuser_privacy_policy'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback block"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    </div>


                                    <div class="form-group">

                                        <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3"></label>

                                        <div class="col-sm-12 col-md-7">

                                            <button type="submit"
                                                class="btn btn-primary demo-button"><?php echo e(__('Save')); ?></button>

                                        </div>

                                    </div>

                                </form>

                            </div>

                        </div>

                    </div>

                </div>

                <div class="col-lg-6">

                        <div class="card card-large-icons">

                            <div class="card-icon bg-primary text-white">

                                <i class="fas fa-solid fa-bug"></i>

                            </div>

                            <div class="card-body">

                                <h4><?php echo e(__('Debug Mode')); ?></h4>

                                <p><?php echo e(__('After setting this ON, You will see the detailed error messages, System becomes vulnerable when this is ON, So Make sure you set this OFF as soon as you are done debugging, It\'s fine if you are on the local server')); ?></p>

                                </p>

                                <a href="#debugMode" aria-controls="additional-setting" role="button"
                                    data-toggle="collapse" class="card-cta"
                                    aria-expanded="false"><?php echo e(__('Change Setting')); ?> <i
                                        class="fas fa-chevron-right"></i></a>

                                <div class="collapse mt-3" id="debugMode">

                                    <form method="post" action="<?php echo e(url('save-debug')); ?>">

                                        <?php echo csrf_field(); ?>

                                        <div class="form-group row mb-4">

                                            <label
                                                class="col-form-label col-12 col-md-4"><?php echo e(__('Debug Mode')); ?></label>

                                            <div class="col-sm-12 col-md-8">

                                                <div class="custom-switches-stacked mt-2">

                                                    <label class="custom-switch pl-0">

                                                    <input type="checkbox" name="app_debug"
                                                        <?php echo e(env('APP_DEBUG') == true ? 'checked' : ''); ?>

                                                        value="1" class="custom-switch-input">

                                                        <span class="custom-switch-indicator"></span>

                                                    </label>

                                                </div>

                                            </div>

                                        </div>

                                        <div class="form-group">

                                            <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3"></label>

                                            <div class="col-sm-12 col-md-7">

                                                <button type="submit"
                                                    class="btn btn-primary demo-button"><?php echo e(__('Save')); ?></button>

                                            </div>

                                        </div>

                                    </form>

                                </div>

                            </div>

                        </div>

                </div>


                </form>
            </div>
        </div>
    </section>
    <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog"
        aria-labelledby="exampleModalCenterTitle" aria-hidden="true">

        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle"><?php echo e(__('Test Mail')); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>

                </div>
                <div class="modal-body">
                    <label class="col-form-label"><?php echo e(__('Recipient Email for SMTP Testing')); ?></label>
                    <input type="email" name="mail_to" id="mail_to" value="<?php echo e(auth()->user()->email); ?>"
                        required class="form-control <?php $__errorArgs = ['mail_to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <?php $__errorArgs = ['mail_to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary"
                        data-dismiss="modal"><?php echo e(__('Close')); ?></button>
                    <button type="button" class="btn btn-primary" id="TestMail"><?php echo e(__('Send')); ?></button>
                </div>
                <div class="emailstatus text-right mr-3" id="emailstatus"></div>
                <div class="emailerror text-right mr-3 " id="emailerror"></div>
            </div>
        </div>
    </div>
    <style>
        .modal-backdrop {
            display: none;
        }
    </style>
    
    <script>
    function toggleFrontend() {
        const hiddenInput = document.getElementById('frontend_maintenance_hidden');
        const currentValue = hiddenInput.value;
        
        // Toggle the value
        hiddenInput.value = currentValue === '1' ? '0' : '1';
        
        // Submit the form
        hiddenInput.closest('form').submit();
    }
    </script>
<?php $__env->stopSection(); ?>
<?php
    $gmapkey = App\Models\Setting::find(1)->map_key;
?>
<?php if($gmapkey): ?>
    <script type="text/javascript" src="https://maps.google.com/maps/api/js?key=<?php echo e($gmapkey); ?>&libraries=places">
    </script>
<?php endif; ?>

<script>
    google.maps.event.addDomListener(window, 'load', initialize);

    function initialize() {
        var input = document.getElementById('address');
        var autocomplete = new google.maps.places.Autocomplete(input);

        autocomplete.addListener('place_changed', function() {
            var place = autocomplete.getPlace();
            $('#latitude').val(place.geometry['location'].lat());
            $('#longitude').val(place.geometry['location'].lng());
        });
    }

    document.addEventListener('DOMContentLoaded', function() {
        document.getElementById('paymentForm').addEventListener('submit', function(event) {
            var checkboxes = document.querySelectorAll('.paymentCheckbox');
            var checked = false;
            checkboxes.forEach(function(checkbox) {
                if (checkbox.checked) {
                    checked = true;
                }
            });
            if (!checked) {
                event.preventDefault();
                document.getElementById('errorMessage').classList.remove('d-none');
            }
        });
    });
</script>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u726836945/domains/starrtix.com/public_html/app/resources/views/admin/setting.blade.php ENDPATH**/ ?>