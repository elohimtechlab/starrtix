<?php $__env->startSection('content'); ?>
    <section class="section">
        <?php echo $__env->make('admin.layout.breadcrumbs', [
            'title' => __('Setting'),
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="section-body">
            <div class="row">
                <div class="col-lg-8">
                    <h2 class="section-title"> <?php echo e(__('Organizer Setting')); ?></h2>
                </div>
                <div class="col-lg-4 text-right">
                </div>
            </div>

            <div class="row">
                <div class="col-12">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?php echo e(session('status')); ?>

                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="col-12">
                    <?php if(session('Exception')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?php echo e(session('Exception')); ?>

                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="col-lg-6">
                    <div class="card card-large-icons">
                        <div class="card-icon bg-primary text-white">
                            <i class="fas fa-hand-holding-usd"></i>
                        </div>
                        <div class="card-body">
                            <h4><?php echo e(__('Payment Setting')); ?></h4>
                            <p><?php echo e(__('Payment settings include different payment gateway and which will display top the admin for the Settlement Payout. Local Payment (cash ) option will be shown to the admin by default. Only selected gateways will be visible.')); ?>

                            </p>
                            <a href="#payment-setting" aria-controls="payment-setting" role="button"
                                data-toggle="collapse" class="card-cta"
                                aria-expanded="false"><?php echo e(__('Change Setting')); ?>

                                <i class="fas fa-chevron-right"></i></a>
                            <div class="collapse mt-3" id="payment-setting">
                                <form method="post" action="<?php echo e(url('payment-save')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group row mb-4">
                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3"><?php echo e(__('Stripe')); ?></label>
                                        <div class="col-sm-12 col-md-9">
                                            <div class="custom-switches-stacked mt-2">
                                                <label class="custom-switch pl-0">
                                                    <input type="checkbox" name="stripe"
                                                        <?php echo e($payment->stripe == '1' ? 'checked' : ''); ?> value="1"
                                                        class="custom-switch-input">
                                                    <span class="custom-switch-indicator"></span>
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group row mb-4">
                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3"><?php echo e(__('Paypal')); ?></label>
                                        <div class="col-sm-12 col-md-9">
                                            <div class="custom-switches-stacked mt-2">
                                                <label class="custom-switch pl-0">
                                                    <input type="checkbox" name="paypal"
                                                        <?php echo e($payment->paypal == '1' ? 'checked' : ''); ?> value="1"
                                                        class="custom-switch-input">
                                                    <span class="custom-switch-indicator"></span>
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group row mb-4">
                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3"><?php echo e(__('Flutterwave')); ?></label>
                                        <div class="col-sm-12 col-md-9">
                                            <div class="custom-switches-stacked mt-2">
                                                <label class="custom-switch pl-0">
                                                    <input type="checkbox" name="flutterwave"
                                                        <?php echo e($payment->flutterwave == '1' ? 'checked' : ''); ?>

                                                        value="1" class="custom-switch-input">
                                                    <span class="custom-switch-indicator"></span>
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group row mb-4">
                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3"><?php echo e(__('Razorpay')); ?></label>
                                        <div class="col-sm-12 col-md-9">
                                            <div class="custom-switches-stacked mt-2">
                                                <label class="custom-switch pl-0">
                                                    <input type="checkbox" name="razor"
                                                        <?php echo e($payment->razor == '1' ? 'checked' : ''); ?> value="1"
                                                        class="custom-switch-input">
                                                    <span class="custom-switch-indicator"></span>
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group row mb-4">
                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Stripe secret key')); ?></label>
                                        <div class="col-sm-12 col-md-9">
                                            <input type="text" name="stripeSecretKey"
                                                placeholder="<?php echo e(__('Stripe secret key')); ?>" value="<?php echo e($payment->stripeSecretKey); ?>"
                                                class="form-control <?php $__errorArgs = ['stripeSecretKey'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <?php $__errorArgs = ['stripeSecretKey'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="form-group row mb-4">
                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Stripe public key')); ?></label>
                                        <div class="col-sm-12 col-md-9">
                                            <input type="text" name="stripePublicKey"
                                                placeholder="<?php echo e(__('Stripe public key')); ?>" value="<?php echo e($payment->stripePublicKey); ?>"
                                                class="form-control <?php $__errorArgs = ['stripePublicKey'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <?php $__errorArgs = ['stripePublicKey'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            <a href="https://stripe.com/docs/keys#obtain-api-keys" target="_blank"
                                                class="btn btn-primary demo-button mt-2"><?php echo e(__('Help')); ?>

                                            </a>
                                        </div>
                                    </div>
                                    <div class="form-group row mb-4">
                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Paypal Client ID')); ?></label>
                                        <div class="col-sm-12 col-md-9">
                                            <input type="text" name="paypalClientId"
                                                placeholder="<?php echo e(__('Paypal Client ID')); ?>" value="<?php echo e($payment->paypalClientId); ?>"
                                                class="form-control <?php $__errorArgs = ['paypalClientId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <?php $__errorArgs = ['paypalClientId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="form-group row mb-4">
                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Paypal Secret key')); ?></label>
                                        <div class="col-sm-12 col-md-9">
                                            <input type="text" name="paypalSecret"
                                                placeholder="<?php echo e(__('Paypal Secret key')); ?>" value="<?php echo e($payment->paypalSecret); ?>"
                                                class="form-control <?php $__errorArgs = ['paypalSecret'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <?php $__errorArgs = ['paypalSecret'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            <a href="https://www.appinvoice.com/en/s/documentation/how-to-get-paypal-client-id-and-secret-key-22"
                                                target="_blank"
                                                class="btn btn-primary demo-button mt-2"><?php echo e(__('Help')); ?>

                                            </a>
                                        </div>
                                    </div>
                                    <div class="form-group row mb-4">
                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Razorpay Publish key')); ?></label>
                                        <div class="col-sm-12 col-md-9">
                                            <input type="text" name="razorPublishKey"
                                                placeholder="<?php echo e(__('Razorpay Publish key')); ?>" value="<?php echo e($payment->razorPublishKey); ?>"
                                                class="form-control <?php $__errorArgs = ['razorPublishKey'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <?php $__errorArgs = ['razorPublishKey'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="form-group row mb-4">
                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Razorpay Secret key')); ?></label>
                                        <div class="col-sm-12 col-md-9">
                                            <input type="text" name="razorSecretKey"
                                                placeholder="<?php echo e(__('Razorpay Secret key')); ?>" value="<?php echo e($payment->razorSecretKey); ?>"
                                                class="form-control <?php $__errorArgs = ['razorSecretKey'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <?php $__errorArgs = ['razorSecretKey'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            <a href="https://razorpay.com/docs/payments/dashboard/settings/api-keys/"
                                                target="_blank"
                                                class="btn btn-primary demo-button mt-2"><?php echo e(__('Help')); ?>

                                            </a>
                                        </div>
                                    </div>
                                    <div class="form-group row mb-4">
                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Flutterwave public key')); ?></label>
                                        <div class="col-sm-12 col-md-9">
                                            <input type="text" name="ravePublicKey"
                                                placeholder="<?php echo e(__('Flutterwave public key')); ?>" value="<?php echo e($payment->ravePublicKey); ?>"
                                                class="form-control <?php $__errorArgs = ['ravePublicKey'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <?php $__errorArgs = ['ravePublicKey'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="form-group row mb-4">
                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Flutterwave secret key')); ?></label>
                                        <div class="col-sm-12 col-md-9">
                                            <input type="text" name="raveSecretKey"
                                                placeholder="<?php echo e(__('Flutterwave secret key')); ?>" value="<?php echo e($payment->raveSecretKey); ?>"
                                                class="form-control <?php $__errorArgs = ['raveSecretKey'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <?php $__errorArgs = ['raveSecretKey'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                <a href="https://developer.flutterwave.com/docs/quickstart" target="_blank"
                                                    class="btn btn-primary demo-button mt-2"><?php echo e(__('Help')); ?>

                                                </a>
                                        </div>
                                    </div>
                                    <div class="form-group row mb-4">
                                        <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3"></label>
                                        <div class="col-sm-12 col-md-7">
                                            <button type="submit"
                                                class="btn btn-primary demo-button"><?php echo e(__('Save')); ?></button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                </form>
            </div>
        </div>
    </section>
    ` <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog"
        aria-labelledby="exampleModalCenterTitle" aria-hidden="true">

        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle"><?php echo e(__('Test Mail')); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>

                </div>
                <div class="modal-body">
                    <label class="col-form-label"><?php echo e(__('Recipient Email for SMTP Testing')); ?></label>
                    <input type="email" name="mail_to" id="mail_to" value="<?php echo e(auth()->user()->email); ?>" required
                        class="form-control <?php $__errorArgs = ['mail_to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <?php $__errorArgs = ['mail_to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo e(__('Close')); ?></button>
                    <button type="button" class="btn btn-primary" id="TestMail"><?php echo e(__('Send')); ?></button>
                </div>
                <div class="emailstatus text-right mr-3" id="emailstatus"></div>
                <div class="emailerror text-right mr-3 " id="emailerror"></div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php
    $gmapkey = App\Models\Setting::find(1)->map_key;
?>
<?php if($gmapkey): ?>
    <script type="text/javascript" src="https://maps.google.com/maps/api/js?key=<?php echo e($gmapkey); ?>&libraries=places">
    </script>
<?php endif; ?>

<script>
    google.maps.event.addDomListener(window, 'load', initialize);

    function initialize() {
        var input = document.getElementById('address');
        var autocomplete = new google.maps.places.Autocomplete(input);

        autocomplete.addListener('place_changed', function() {
            var place = autocomplete.getPlace();
            $('#latitude').val(place.geometry['location'].lat());
            $('#longitude').val(place.geometry['location'].lng());
        });
    }
</script>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u726836945/domains/starrtix.com/public_html/app/resources/views/admin/organizer/organizerSetting.blade.php ENDPATH**/ ?>