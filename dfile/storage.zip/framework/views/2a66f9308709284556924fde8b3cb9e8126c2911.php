<?php $__env->startSection('content'); ?>
<section class="section">
    <?php echo $__env->make('admin.layout.breadcrumbs', [
        'title' => __('Create Event'),
        'headerData' => __('Event'),
        'url' => 'events',
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="section-body">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <!-- Step Progress Indicator -->
                        <div class="step-progress mb-4">
                            <div class="step-container">
                                <div class="step active" data-step="1">
                                    <div class="step-circle">
                                        <i class="fas fa-info-circle"></i>
                                    </div>
                                    <span class="step-label">What</span>
                                </div>
                                <div class="step" data-step="2">
                                    <div class="step-circle">
                                        <i class="fas fa-map-marker-alt"></i>
                                    </div>
                                    <span class="step-label">Where</span>
                                </div>
                                <div class="step" data-step="3">
                                    <div class="step-circle">
                                        <i class="fas fa-clock"></i>
                                    </div>
                                    <span class="step-label">When</span>
                                </div>
                                <div class="step" data-step="4">
                                    <div class="step-circle">
                                        <i class="fas fa-dollar-sign"></i>
                                    </div>
                                    <span class="step-label">How much</span>
                                </div>
                                <div class="step" data-step="5">
                                    <div class="step-circle">
                                        <i class="fas fa-upload"></i>
                                    </div>
                                    <span class="step-label">Upload</span>
                                </div>
                            </div>
                        </div>

                        <form method="post" class="event-wizard-form" action="<?php echo e(url('events')); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            
                            <!-- Step 1: What (Event Details) -->
                            <div class="step-content active" id="step-1">
                                <div class="text-center mb-4">
                                    <h3 class="step-title">Event Details</h3>
                                    <p class="step-subtitle text-muted">Upload your event in just 7 steps</p>
                                </div>

                                <div class="row justify-content-center">
                                    <div class="col-lg-8">
                                        <div class="form-group">
                                            <label class="form-label"><?php echo e(__('Event Title')); ?> <span class="text-danger">*</span></label>
                                            <input type="text" name="name" id="event-title" value="<?php echo e(old('name')); ?>"
                                                placeholder="<?php echo e(__('Enter your event title')); ?>"
                                                class="form-control form-control-lg <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="form-group">
                                            <label class="form-label"><?php echo e(__('Event Category')); ?> <span class="text-danger">*</span></label>
                                            <select name="category_id" id="event-category" class="form-control form-control-lg select2">
                                                <option value=""><?php echo e(__('Select Category')); ?></option>
                                                <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item->id); ?>" <?php echo e($item->id == old('category_id') ? 'selected' : ''); ?>>
                                                        <?php echo e($item->name); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="form-group">
                                            <label class="form-label"><?php echo e(__('Payment Acceptance')); ?> <span class="text-danger">*</span></label>
                                            <div class="payment-options">
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input" type="radio" name="type" id="free-event" value="free">
                                                    <label class="form-check-label" for="free-event">
                                                        <div class="payment-card">
                                                            <i class="fas fa-gift"></i>
                                                            <span>Free</span>
                                                        </div>
                                                    </label>
                                                </div>
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input" type="radio" name="type" id="paid-event" value="paid" checked>
                                                    <label class="form-check-label" for="paid-event">
                                                        <div class="payment-card active">
                                                            <i class="fas fa-credit-card"></i>
                                                            <span>Paid</span>
                                                        </div>
                                                    </label>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="form-navigation text-center mt-4">
                                            <button type="button" class="btn btn-primary btn-lg next-step">
                                                <?php echo e(__('Next')); ?> <i class="fas fa-arrow-right ml-2"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Additional steps will be added in separate files -->
                            <?php echo $__env->make('admin.event.wizard-steps.step-2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php echo $__env->make('admin.event.wizard-steps.step-3', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php echo $__env->make('admin.event.wizard-steps.step-4', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php echo $__env->make('admin.event.wizard-steps.step-5', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                            <!-- Hidden fields for existing functionality -->
                            <input type="hidden" name="people" value="100">
                            <input type="hidden" name="status" value="1">
                            <input type="hidden" name="description" value="">
                            <?php if(Auth::user()->hasRole('admin')): ?>
                                <input type="hidden" name="user_id" value="">
                            <?php endif; ?>
                            <input type="hidden" name="scanner_id[]" value="">
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php echo $__env->make('admin.event.wizard-styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.event.wizard-scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.event.preview-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u726836945/domains/starrtix.com/public_html/app/resources/views/admin/event/create-wizard.blade.php ENDPATH**/ ?>