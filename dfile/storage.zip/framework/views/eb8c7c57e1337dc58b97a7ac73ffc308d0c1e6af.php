<!-- Step 2: Where (Location & Address) -->
<div class="step-content" id="step-2">
    <div class="text-center mb-4">
        <h3 class="step-title">Event Location & Address</h3>
        <p class="step-subtitle text-muted">We don't want anyone <span class="text-warning">getting lost</span> or missing out.</p>
    </div>

    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="form-group">
                <label class="form-label"><?php echo e(__('Search Address')); ?> <span class="text-danger">*</span></label>
                <input type="text" name="address" id="address" value="<?php echo e(old('address')); ?>"
                    placeholder="<?php echo e(__('Aberdeen')); ?>"
                    class="form-control form-control-lg <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label class="form-label"><?php echo e(__('Map Coordinates')); ?></label>
                <input type="text" name="lat_long" id="lat_long" value="<?php echo e(old('lat_long')); ?>"
                    placeholder="<?php echo e(__('-0.39837363, 1.37352234')); ?>"
                    class="form-control form-control-lg <?php $__errorArgs = ['lat_long'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <?php $__errorArgs = ['lat_long'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-navigation text-center mt-4">
                <button type="button" class="btn btn-outline-secondary btn-lg prev-step mr-3">
                    <i class="fas fa-arrow-left mr-2"></i> <?php echo e(__('Previous')); ?>

                </button>
                <button type="button" class="btn btn-primary btn-lg next-step">
                    <?php echo e(__('Next')); ?> <i class="fas fa-arrow-right ml-2"></i>
                </button>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/u726836945/domains/starrtix.com/public_html/app/resources/views/admin/event/wizard-steps/step-2.blade.php ENDPATH**/ ?>