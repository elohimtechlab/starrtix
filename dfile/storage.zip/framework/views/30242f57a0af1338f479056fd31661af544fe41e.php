<head>
    <style>
        .mycustomqrcode {
            padding: 10px;
            background-color: white;
            width: fit-content;
            block-size: fit-content;

        }

        .mycustomqrcode>img {
            height: 150px;
            width: 150px;
        }
    </style>
</head>

<body>
    <div class="mailMessage">
        <?php echo $content; ?>

    </div>
</body>
<?php /**PATH /home/u726836945/domains/starrtix.com/public_html/app/resources/views/admin/mailMessage.blade.php ENDPATH**/ ?>