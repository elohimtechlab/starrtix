<?php

declare(strict_types=1);

namespace Bavix\Wallet\Internal\Exceptions;

use UnderflowException;

final class RecordNotFoundException extends UnderflowException implements UnderflowExceptionInterface
{
}
