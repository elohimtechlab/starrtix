<?php

declare(strict_types=1);

namespace Bavix\Wallet\Internal\Exceptions;

interface LogicExceptionInterface extends ExceptionInterface
{
}
