<?php

declare(strict_types=1);

namespace Bavix\Wallet\Test\Infra\PackageModels;

class Transfer extends \Bavix\Wallet\Models\Transfer
{
}
