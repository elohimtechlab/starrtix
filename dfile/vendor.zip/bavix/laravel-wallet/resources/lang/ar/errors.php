<?php

declare(strict_types=1);

return [
    'price_positive' => 'يجب أن يكون السعر موجبًا',
    'product_stock' => 'المنتج غير متوفر',
    'wallet_empty' => 'المحفظة فارغة',
    'insufficient_funds' => 'الأموال غير الكافية',
    'confirmed_invalid' => 'تم التأكيد بالفعل',
    'unconfirmed_invalid' => 'التأكيد تمت إعادة تعيينه بالفعل',
    'owner_invalid' => 'أنت لست مالك المحفظة',
];
