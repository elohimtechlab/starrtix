<?php

declare(strict_types=1);

return [
    'price_positive' => 'قیمت باید عددی مثبت باشد',
    'product_stock' => 'کالا موجود نیست',
    'wallet_empty' => 'کیف پول خالی است',
    'insufficient_funds' => 'موجودی ناکافی',
    'confirmed_invalid' => 'تراکنش قبلا تایید شده است',
    'unconfirmed_invalid' => 'تاییدیه تراکنش لغو شده است',
    'owner_invalid' => 'این کیف پول متعلق به شما نیست',
];
