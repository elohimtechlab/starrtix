<?php

declare(strict_types=1);

return [
    'price_positive' => 'Цена должна быть положительной',
    'product_stock' => 'Товар отсутствует',
    'wallet_empty' => 'Кошелёк пуст',
    'insufficient_funds' => 'Недостаточно средств',
    'confirmed_invalid' => 'Перевод уже подтвержден',
    'unconfirmed_invalid' => 'Подтверждение уже сброшено',
    'owner_invalid' => 'Вы не владелец кошелька',
];
