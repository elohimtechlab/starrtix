<footer class="main-footer">
    <div class="footer-left">
    {{\App\Models\Setting::find(1)->footertext}}
    </div>
    <div class="footer-right">
      {{\App\Models\Setting::find(1)->app_version}}
    </div>
</footer>
