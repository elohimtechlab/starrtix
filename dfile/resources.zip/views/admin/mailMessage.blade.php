<head>
    <style>
        .mycustomqrcode {
            padding: 10px;
            background-color: white;
            width: fit-content;
            block-size: fit-content;

        }

        .mycustomqrcode>img {
            height: 150px;
            width: 150px;
        }
    </style>
</head>

<body>
    <div class="mailMessage">
        {!! $content !!}
    </div>
</body>
